// ==========================================
// CONSTRUCTION EQUIPMENT RENTAL - DATA MODELS
// ==========================================

export type UserRole = 'admin' | 'staff';
export type EquipmentStatus = 'Available' | 'Rented' | 'Maintenance';
export type RentalStatus = 'Active' | 'Returned' | 'Overdue';
export type PaymentStatus = 'Pending' | 'Partial' | 'Paid';
export type PaymentMethod = 'Cash' | 'Card' | 'Bank Transfer' | 'Check';
export type MaintenanceStatus = 'Scheduled' | 'In Progress' | 'Completed';

export interface User {
  id: string;
  username: string;
  password: string;
  fullName: string;
  role: UserRole;
  email: string;
  active: boolean;
  createdAt: Date;
}

export interface Equipment {
  id: string;
  name: string;
  category: string;
  brand: string;
  model: string;
  serialNumber: string;
  status: EquipmentStatus;
  dailyRate: number;
  weeklyRate: number;
  monthlyRate: number;
  purchaseDate: Date;
  purchaseCost: number;
  description: string;
  imageUrl?: string;
  createdAt: Date;
}

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  company: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  idNumber: string;
  notes: string;
  createdAt: Date;
}

export interface Rental {
  id: string;
  customerId: string;
  rentalDate: Date;
  expectedReturnDate: Date;
  actualReturnDate?: Date;
  status: RentalStatus;
  totalAmount: number;
  deposit: number;
  lateFee: number;
  damageFee: number;
  notes: string;
  createdBy: string;
  createdAt: Date;
}

export interface RentalDetail {
  id: string;
  rentalId: string;
  equipmentId: string;
  dailyRate: number;
  weeklyRate: number;
  monthlyRate: number;
  appliedRate: number;
  days: number;
  subtotal: number;
}

export interface Payment {
  id: string;
  rentalId: string;
  amount: number;
  paymentDate: Date;
  paymentMethod: PaymentMethod;
  reference: string;
  notes: string;
  createdAt: Date;
}

export interface Maintenance {
  id: string;
  equipmentId: string;
  description: string;
  startDate: Date;
  endDate?: Date;
  cost: number;
  status: MaintenanceStatus;
  performedBy: string;
  notes: string;
  createdAt: Date;
}

// Dashboard stats
export interface DashboardStats {
  totalEquipment: number;
  availableEquipment: number;
  rentedEquipment: number;
  maintenanceEquipment: number;
  totalCustomers: number;
  activeRentals: number;
  monthlyRevenue: number;
  pendingPayments: number;
  overdueRentals: number;
  totalMaintenanceCost: number;
}

// Report types
export interface RevenueReport {
  month: string;
  revenue: number;
  rentals: number;
}

export interface MostRentedEquipment {
  equipmentName: string;
  timesRented: number;
  totalRevenue: number;
}

export interface LateReturnReport {
  rentalId: string;
  customerName: string;
  equipmentNames: string[];
  daysLate: number;
  lateFee: number;
}
