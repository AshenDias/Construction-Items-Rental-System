// ============================================
// UNIFIED DATA STORE
// Automatically uses Firebase when configured,
// falls back to localStorage when offline or not configured
// ============================================

import { isFirebaseConfigured } from '../firebase/config';
import {
  FirebaseUserDAO, FirebaseEquipmentDAO, FirebaseCustomerDAO,
  FirebaseRentalDAO, FirebaseRentalDetailDAO, FirebasePaymentDAO,
  FirebaseMaintenanceDAO, seedInitialData,
} from '../firebase/firebaseStore';
import {
  UserDAO as LocalUserDAO, EquipmentDAO as LocalEquipmentDAO,
  CustomerDAO as LocalCustomerDAO, RentalDAO as LocalRentalDAO,
  RentalDetailDAO as LocalRentalDetailDAO, PaymentDAO as LocalPaymentDAO,
  MaintenanceDAO as LocalMaintenanceDAO, DashboardService as LocalDashboardService,
  RentalPricingService,
} from './dataStore';
import {
  User, Equipment, Customer, Rental, RentalDetail,
  Payment, Maintenance, EquipmentStatus, DashboardStats,
} from '../types';

// Check if we should use Firebase
const useFirebase = isFirebaseConfigured();

console.log(useFirebase ? '🔥 Using Firebase (real-time sync enabled)' : '💾 Using localStorage (offline mode)');

// Initialize Firebase data if configured
if (useFirebase) {
  seedInitialData().catch(console.error);
}

// ============================================
// UNIFIED USER DAO
// ============================================
export const UserDAO = {
  findAll: async (): Promise<User[]> => {
    return useFirebase ? await FirebaseUserDAO.findAll() : LocalUserDAO.findAll();
  },
  findById: async (id: string): Promise<User | null> => {
    return useFirebase ? await FirebaseUserDAO.findById(id) : LocalUserDAO.findById(id);
  },
  findByCredentials: async (username: string, password: string): Promise<User | null> => {
    return useFirebase 
      ? await FirebaseUserDAO.findByCredentials(username, password) 
      : LocalUserDAO.findByCredentials(username, password);
  },
};

// ============================================
// UNIFIED EQUIPMENT DAO
// ============================================
export const EquipmentDAO = {
  findAll: async (): Promise<Equipment[]> => {
    return useFirebase ? await FirebaseEquipmentDAO.findAll() : LocalEquipmentDAO.findAll();
  },
  findById: async (id: string): Promise<Equipment | null> => {
    return useFirebase ? await FirebaseEquipmentDAO.findById(id) : LocalEquipmentDAO.findById(id);
  },
  findByStatus: async (status: EquipmentStatus): Promise<Equipment[]> => {
    return useFirebase ? await FirebaseEquipmentDAO.findByStatus(status) : LocalEquipmentDAO.findByStatus(status);
  },
  save: async (equipment: Equipment): Promise<void> => {
    if (useFirebase) {
      await FirebaseEquipmentDAO.save(equipment);
    } else {
      LocalEquipmentDAO.save(equipment);
    }
  },
  delete: async (id: string): Promise<boolean> => {
    return useFirebase ? await FirebaseEquipmentDAO.delete(id) : LocalEquipmentDAO.delete(id);
  },
  updateStatus: async (id: string, status: EquipmentStatus): Promise<void> => {
    if (useFirebase) {
      await FirebaseEquipmentDAO.updateStatus(id, status);
    } else {
      LocalEquipmentDAO.updateStatus(id, status);
    }
  },
  generateId: async (): Promise<string> => {
    return useFirebase ? await FirebaseEquipmentDAO.generateId() : LocalEquipmentDAO.generateId();
  },
  getCategories: (): string[] => LocalEquipmentDAO.getCategories(),
  onSnapshot: useFirebase ? FirebaseEquipmentDAO.onSnapshot : undefined,
};

// ============================================
// UNIFIED CUSTOMER DAO
// ============================================
export const CustomerDAO = {
  findAll: async (): Promise<Customer[]> => {
    return useFirebase ? await FirebaseCustomerDAO.findAll() : LocalCustomerDAO.findAll();
  },
  findById: async (id: string): Promise<Customer | null> => {
    return useFirebase ? await FirebaseCustomerDAO.findById(id) : LocalCustomerDAO.findById(id);
  },
  findByEmail: async (email: string): Promise<Customer | null> => {
    return useFirebase ? await FirebaseCustomerDAO.findByEmail(email) : LocalCustomerDAO.findByEmail(email);
  },
  save: async (customer: Customer): Promise<void> => {
    if (useFirebase) {
      await FirebaseCustomerDAO.save(customer);
    } else {
      LocalCustomerDAO.save(customer);
    }
  },
  delete: async (id: string): Promise<boolean> => {
    return useFirebase ? await FirebaseCustomerDAO.delete(id) : LocalCustomerDAO.delete(id);
  },
  generateId: async (): Promise<string> => {
    return useFirebase ? await FirebaseCustomerDAO.generateId() : LocalCustomerDAO.generateId();
  },
  onSnapshot: useFirebase ? FirebaseCustomerDAO.onSnapshot : undefined,
};

// ============================================
// UNIFIED RENTAL DAO
// ============================================
export const RentalDAO = {
  findAll: async (): Promise<Rental[]> => {
    return useFirebase ? await FirebaseRentalDAO.findAll() : LocalRentalDAO.findAll();
  },
  findById: async (id: string): Promise<Rental | null> => {
    return useFirebase ? await FirebaseRentalDAO.findById(id) : LocalRentalDAO.findById(id);
  },
  findByCustomer: async (customerId: string): Promise<Rental[]> => {
    return useFirebase ? await FirebaseRentalDAO.findByCustomer(customerId) : LocalRentalDAO.findByCustomer(customerId);
  },
  save: async (rental: Rental): Promise<void> => {
    if (useFirebase) {
      await FirebaseRentalDAO.save(rental);
    } else {
      LocalRentalDAO.save(rental);
    }
  },
  generateId: async (): Promise<string> => {
    return useFirebase ? await FirebaseRentalDAO.generateId() : LocalRentalDAO.generateId();
  },
  onSnapshot: useFirebase ? FirebaseRentalDAO.onSnapshot : undefined,
};

// ============================================
// UNIFIED RENTAL DETAIL DAO
// ============================================
export const RentalDetailDAO = {
  findAll: async (): Promise<RentalDetail[]> => {
    return useFirebase ? await FirebaseRentalDetailDAO.findAll() : LocalRentalDetailDAO.findAll();
  },
  findByRental: async (rentalId: string): Promise<RentalDetail[]> => {
    return useFirebase ? await FirebaseRentalDetailDAO.findByRental(rentalId) : LocalRentalDetailDAO.findByRental(rentalId);
  },
  save: async (detail: RentalDetail): Promise<void> => {
    if (useFirebase) {
      await FirebaseRentalDetailDAO.save(detail);
    } else {
      LocalRentalDetailDAO.save(detail);
    }
  },
  saveAll: async (details: RentalDetail[]): Promise<void> => {
    if (useFirebase) {
      await FirebaseRentalDetailDAO.saveAll(details);
    } else {
      LocalRentalDetailDAO.saveAll(details);
    }
  },
  generateId: (): string => {
    return useFirebase ? FirebaseRentalDetailDAO.generateId() : LocalRentalDetailDAO.generateId();
  },
};

// ============================================
// UNIFIED PAYMENT DAO
// ============================================
export const PaymentDAO = {
  findAll: async (): Promise<Payment[]> => {
    return useFirebase ? await FirebasePaymentDAO.findAll() : LocalPaymentDAO.findAll();
  },
  findByRental: async (rentalId: string): Promise<Payment[]> => {
    return useFirebase ? await FirebasePaymentDAO.findByRental(rentalId) : LocalPaymentDAO.findByRental(rentalId);
  },
  save: async (payment: Payment): Promise<void> => {
    if (useFirebase) {
      await FirebasePaymentDAO.save(payment);
    } else {
      LocalPaymentDAO.save(payment);
    }
  },
  getTotalByRental: async (rentalId: string): Promise<number> => {
    return useFirebase ? await FirebasePaymentDAO.getTotalByRental(rentalId) : LocalPaymentDAO.getTotalByRental(rentalId);
  },
  generateId: async (): Promise<string> => {
    return useFirebase ? await FirebasePaymentDAO.generateId() : LocalPaymentDAO.generateId();
  },
  onSnapshot: useFirebase ? FirebasePaymentDAO.onSnapshot : undefined,
};

// ============================================
// UNIFIED MAINTENANCE DAO
// ============================================
export const MaintenanceDAO = {
  findAll: async (): Promise<Maintenance[]> => {
    return useFirebase ? await FirebaseMaintenanceDAO.findAll() : LocalMaintenanceDAO.findAll();
  },
  findById: async (id: string): Promise<Maintenance | null> => {
    return useFirebase ? await FirebaseMaintenanceDAO.findById(id) : LocalMaintenanceDAO.findById(id);
  },
  findByEquipment: async (equipmentId: string): Promise<Maintenance[]> => {
    return useFirebase ? await FirebaseMaintenanceDAO.findByEquipment(equipmentId) : LocalMaintenanceDAO.findByEquipment(equipmentId);
  },
  save: async (maintenance: Maintenance): Promise<void> => {
    if (useFirebase) {
      await FirebaseMaintenanceDAO.save(maintenance);
    } else {
      LocalMaintenanceDAO.save(maintenance);
    }
  },
  delete: async (id: string): Promise<boolean> => {
    return useFirebase ? await FirebaseMaintenanceDAO.delete(id) : LocalMaintenanceDAO.delete(id);
  },
  generateId: async (): Promise<string> => {
    return useFirebase ? await FirebaseMaintenanceDAO.generateId() : LocalMaintenanceDAO.generateId();
  },
  onSnapshot: useFirebase ? FirebaseMaintenanceDAO.onSnapshot : undefined,
};

// ============================================
// DASHBOARD SERVICE (Unified)
// ============================================
export const DashboardService = {
  getStats: async (): Promise<DashboardStats> => {
    if (!useFirebase) return LocalDashboardService.getStats();
    
    const [equipment, customers, rentals, payments, maintenance] = await Promise.all([
      EquipmentDAO.findAll(),
      CustomerDAO.findAll(),
      RentalDAO.findAll(),
      PaymentDAO.findAll(),
      MaintenanceDAO.findAll(),
    ]);

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const monthlyPayments = payments.filter(p => {
      const d = new Date(p.paymentDate);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const monthlyRevenue = monthlyPayments.reduce((sum, p) => sum + p.amount, 0);
    const activeRentals = rentals.filter(r => r.status === 'Active');
    
    let pendingPaymentsAmount = 0;
    for (const r of activeRentals) {
      const paid = await PaymentDAO.getTotalByRental(r.id);
      pendingPaymentsAmount += (r.totalAmount - paid);
    }

    const overdueRentals = activeRentals.filter(r => {
      const expected = new Date(r.expectedReturnDate);
      return expected < now;
    });

    const totalMaintenanceCost = maintenance.reduce((sum, m) => sum + m.cost, 0);

    return {
      totalEquipment: equipment.length,
      availableEquipment: equipment.filter(e => e.status === 'Available').length,
      rentedEquipment: equipment.filter(e => e.status === 'Rented').length,
      maintenanceEquipment: equipment.filter(e => e.status === 'Maintenance').length,
      totalCustomers: customers.length,
      activeRentals: activeRentals.length,
      monthlyRevenue,
      pendingPayments: pendingPaymentsAmount,
      overdueRentals: overdueRentals.length,
      totalMaintenanceCost,
    };
  },

  getRevenueByMonth: async () => {
    const payments = await PaymentDAO.findAll();
    const monthlyData: Record<string, { revenue: number; rentals: Set<string> }> = {};

    payments.forEach(p => {
      const d = new Date(p.paymentDate);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      if (!monthlyData[key]) {
        monthlyData[key] = { revenue: 0, rentals: new Set() };
      }
      monthlyData[key].revenue += p.amount;
      monthlyData[key].rentals.add(p.rentalId);
    });

    return Object.entries(monthlyData)
      .map(([month, data]) => ({
        month,
        revenue: data.revenue,
        rentals: data.rentals.size,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));
  },

  getMostRentedEquipment: async () => {
    const details = await RentalDetailDAO.findAll();
    const equipment = await EquipmentDAO.findAll();
    const equipmentStats: Record<string, { count: number; revenue: number }> = {};

    details.forEach(d => {
      if (!equipmentStats[d.equipmentId]) {
        equipmentStats[d.equipmentId] = { count: 0, revenue: 0 };
      }
      equipmentStats[d.equipmentId].count++;
      equipmentStats[d.equipmentId].revenue += d.subtotal;
    });

    return Object.entries(equipmentStats)
      .map(([eqId, stats]) => {
        const eq = equipment.find(e => e.id === eqId);
        return {
          equipmentName: eq?.name || eqId,
          timesRented: stats.count,
          totalRevenue: stats.revenue,
        };
      })
      .sort((a, b) => b.timesRented - a.timesRented);
  },
};

// Re-export pricing service (no change needed)
export { RentalPricingService };

// Export Firebase status
export const isUsingFirebase = useFirebase;
