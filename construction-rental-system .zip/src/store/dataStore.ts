// ==========================================
// DATA STORE - Simulates DAO + Database Layer
// Uses localStorage for persistence
// ==========================================

import {
  User, Equipment, Customer, Rental, RentalDetail,
  Payment, Maintenance, DashboardStats, EquipmentStatus, RentalStatus,
} from '../types';
import {
  sampleUsers, sampleEquipment, sampleCustomers,
  sampleRentals, sampleRentalDetails, samplePayments,
  sampleMaintenance
} from '../data/sampleData';

const STORAGE_KEYS = {
  users: 'cers_users',
  equipment: 'cers_equipment',
  customers: 'cers_customers',
  rentals: 'cers_rentals',
  rentalDetails: 'cers_rental_details',
  payments: 'cers_payments',
  maintenance: 'cers_maintenance',
  initialized: 'cers_initialized',
};

function loadData<T>(key: string, defaults: T[]): T[] {
  try {
    const stored = localStorage.getItem(key);
    if (stored) {
      return JSON.parse(stored, (_k, v) => {
        if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v)) {
          return new Date(v);
        }
        return v;
      });
    }
  } catch (e) {
    console.error(`Error loading ${key}:`, e);
  }
  return defaults;
}

function saveData<T>(key: string, data: T[]): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Error saving ${key}:`, e);
  }
}

function initializeIfNeeded(): void {
  if (!localStorage.getItem(STORAGE_KEYS.initialized)) {
    saveData(STORAGE_KEYS.users, sampleUsers);
    saveData(STORAGE_KEYS.equipment, sampleEquipment);
    saveData(STORAGE_KEYS.customers, sampleCustomers);
    saveData(STORAGE_KEYS.rentals, sampleRentals);
    saveData(STORAGE_KEYS.rentalDetails, sampleRentalDetails);
    saveData(STORAGE_KEYS.payments, samplePayments);
    saveData(STORAGE_KEYS.maintenance, sampleMaintenance);
    localStorage.setItem(STORAGE_KEYS.initialized, 'true');
  }
}

initializeIfNeeded();

// ==========================================
// USER DAO
// ==========================================
export const UserDAO = {
  findAll: (): User[] => loadData(STORAGE_KEYS.users, sampleUsers),

  findByCredentials: (username: string, password: string): User | null => {
    const users = UserDAO.findAll();
    return users.find(u => u.username === username && u.password === password && u.active) || null;
  },

  findById: (id: string): User | null => {
    return UserDAO.findAll().find(u => u.id === id) || null;
  },
};

// ==========================================
// EQUIPMENT DAO
// ==========================================
export const EquipmentDAO = {
  findAll: (): Equipment[] => loadData(STORAGE_KEYS.equipment, sampleEquipment),

  findById: (id: string): Equipment | null => {
    return EquipmentDAO.findAll().find(e => e.id === id) || null;
  },

  findByStatus: (status: EquipmentStatus): Equipment[] => {
    return EquipmentDAO.findAll().filter(e => e.status === status);
  },

  save: (equipment: Equipment): void => {
    const all = EquipmentDAO.findAll();
    const index = all.findIndex(e => e.id === equipment.id);
    if (index >= 0) {
      all[index] = equipment;
    } else {
      all.push(equipment);
    }
    saveData(STORAGE_KEYS.equipment, all);
  },

  delete: (id: string): boolean => {
    const all = EquipmentDAO.findAll();
    const filtered = all.filter(e => e.id !== id);
    if (filtered.length < all.length) {
      saveData(STORAGE_KEYS.equipment, filtered);
      return true;
    }
    return false;
  },

  updateStatus: (id: string, status: EquipmentStatus): void => {
    const equipment = EquipmentDAO.findById(id);
    if (equipment) {
      equipment.status = status;
      EquipmentDAO.save(equipment);
    }
  },

  getCategories: (): string[] => {
    const all = EquipmentDAO.findAll();
    return [...new Set(all.map(e => e.category))];
  },

  generateId: (): string => {
    const all = EquipmentDAO.findAll();
    const maxNum = all.reduce((max, e) => {
      const num = parseInt(e.id.replace('EQP', ''));
      return num > max ? num : max;
    }, 0);
    return `EQP${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ==========================================
// CUSTOMER DAO
// ==========================================
export const CustomerDAO = {
  findAll: (): Customer[] => loadData(STORAGE_KEYS.customers, sampleCustomers),

  findById: (id: string): Customer | null => {
    return CustomerDAO.findAll().find(c => c.id === id) || null;
  },

  save: (customer: Customer): void => {
    const all = CustomerDAO.findAll();
    const index = all.findIndex(c => c.id === customer.id);
    if (index >= 0) {
      all[index] = customer;
    } else {
      all.push(customer);
    }
    saveData(STORAGE_KEYS.customers, all);
  },

  delete: (id: string): boolean => {
    const all = CustomerDAO.findAll();
    const filtered = all.filter(c => c.id !== id);
    if (filtered.length < all.length) {
      saveData(STORAGE_KEYS.customers, filtered);
      return true;
    }
    return false;
  },

  findByEmail: (email: string): Customer | null => {
    return CustomerDAO.findAll().find(c => c.email === email) || null;
  },

  generateId: (): string => {
    const all = CustomerDAO.findAll();
    const maxNum = all.reduce((max, c) => {
      const num = parseInt(c.id.replace('CUS', ''));
      return num > max ? num : max;
    }, 0);
    return `CUS${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ==========================================
// RENTAL DAO
// ==========================================
export const RentalDAO = {
  findAll: (): Rental[] => loadData(STORAGE_KEYS.rentals, sampleRentals),

  findById: (id: string): Rental | null => {
    return RentalDAO.findAll().find(r => r.id === id) || null;
  },

  findByCustomer: (customerId: string): Rental[] => {
    return RentalDAO.findAll().filter(r => r.customerId === customerId);
  },

  findByStatus: (status: RentalStatus): Rental[] => {
    return RentalDAO.findAll().filter(r => r.status === status);
  },

  save: (rental: Rental): void => {
    const all = RentalDAO.findAll();
    const index = all.findIndex(r => r.id === rental.id);
    if (index >= 0) {
      all[index] = rental;
    } else {
      all.push(rental);
    }
    saveData(STORAGE_KEYS.rentals, all);
  },

  generateId: (): string => {
    const all = RentalDAO.findAll();
    const maxNum = all.reduce((max, r) => {
      const num = parseInt(r.id.replace('RNT', ''));
      return num > max ? num : max;
    }, 0);
    return `RNT${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ==========================================
// RENTAL DETAIL DAO
// ==========================================
export const RentalDetailDAO = {
  findAll: (): RentalDetail[] => loadData(STORAGE_KEYS.rentalDetails, sampleRentalDetails),

  findByRental: (rentalId: string): RentalDetail[] => {
    return RentalDetailDAO.findAll().filter(rd => rd.rentalId === rentalId);
  },

  save: (detail: RentalDetail): void => {
    const all = RentalDetailDAO.findAll();
    const index = all.findIndex(rd => rd.id === detail.id);
    if (index >= 0) {
      all[index] = detail;
    } else {
      all.push(detail);
    }
    saveData(STORAGE_KEYS.rentalDetails, all);
  },

  saveAll: (details: RentalDetail[]): void => {
    const all = RentalDetailDAO.findAll();
    details.forEach(detail => {
      const index = all.findIndex(rd => rd.id === detail.id);
      if (index >= 0) {
        all[index] = detail;
      } else {
        all.push(detail);
      }
    });
    saveData(STORAGE_KEYS.rentalDetails, all);
  },

  generateId: (): string => {
    const all = RentalDetailDAO.findAll();
    const maxNum = all.reduce((max, rd) => {
      const num = parseInt(rd.id.replace('RD', ''));
      return num > max ? num : max;
    }, 0);
    return `RD${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ==========================================
// PAYMENT DAO
// ==========================================
export const PaymentDAO = {
  findAll: (): Payment[] => loadData(STORAGE_KEYS.payments, samplePayments),

  findByRental: (rentalId: string): Payment[] => {
    return PaymentDAO.findAll().filter(p => p.rentalId === rentalId);
  },

  save: (payment: Payment): void => {
    const all = PaymentDAO.findAll();
    const index = all.findIndex(p => p.id === payment.id);
    if (index >= 0) {
      all[index] = payment;
    } else {
      all.push(payment);
    }
    saveData(STORAGE_KEYS.payments, all);
  },

  getTotalByRental: (rentalId: string): number => {
    return PaymentDAO.findByRental(rentalId).reduce((sum, p) => sum + p.amount, 0);
  },

  generateId: (): string => {
    const all = PaymentDAO.findAll();
    const maxNum = all.reduce((max, p) => {
      const num = parseInt(p.id.replace('PAY', ''));
      return num > max ? num : max;
    }, 0);
    return `PAY${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ==========================================
// MAINTENANCE DAO
// ==========================================
export const MaintenanceDAO = {
  findAll: (): Maintenance[] => loadData(STORAGE_KEYS.maintenance, sampleMaintenance),

  findByEquipment: (equipmentId: string): Maintenance[] => {
    return MaintenanceDAO.findAll().filter(m => m.equipmentId === equipmentId);
  },

  findById: (id: string): Maintenance | null => {
    return MaintenanceDAO.findAll().find(m => m.id === id) || null;
  },

  save: (maintenance: Maintenance): void => {
    const all = MaintenanceDAO.findAll();
    const index = all.findIndex(m => m.id === maintenance.id);
    if (index >= 0) {
      all[index] = maintenance;
    } else {
      all.push(maintenance);
    }
    saveData(STORAGE_KEYS.maintenance, all);
  },

  delete: (id: string): boolean => {
    const all = MaintenanceDAO.findAll();
    const filtered = all.filter(m => m.id !== id);
    if (filtered.length < all.length) {
      saveData(STORAGE_KEYS.maintenance, filtered);
      return true;
    }
    return false;
  },

  generateId: (): string => {
    const all = MaintenanceDAO.findAll();
    const maxNum = all.reduce((max, m) => {
      const num = parseInt(m.id.replace('MNT', ''));
      return num > max ? num : max;
    }, 0);
    return `MNT${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ==========================================
// DASHBOARD / REPORTING SERVICE
// ==========================================
export const DashboardService = {
  getStats: (): DashboardStats => {
    const equipment = EquipmentDAO.findAll();
    const customers = CustomerDAO.findAll();
    const rentals = RentalDAO.findAll();
    const payments = PaymentDAO.findAll();
    const maintenance = MaintenanceDAO.findAll();

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const monthlyPayments = payments.filter(p => {
      const d = new Date(p.paymentDate);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const monthlyRevenue = monthlyPayments.reduce((sum, p) => sum + p.amount, 0);

    const activeRentals = rentals.filter(r => r.status === 'Active');
    const pendingPaymentsAmount = activeRentals.reduce((sum, r) => {
      const paid = PaymentDAO.getTotalByRental(r.id);
      return sum + (r.totalAmount - paid);
    }, 0);

    const overdueRentals = activeRentals.filter(r => {
      const expected = new Date(r.expectedReturnDate);
      return expected < now;
    });

    const totalMaintenanceCost = maintenance.reduce((sum, m) => sum + m.cost, 0);

    return {
      totalEquipment: equipment.length,
      availableEquipment: equipment.filter(e => e.status === 'Available').length,
      rentedEquipment: equipment.filter(e => e.status === 'Rented').length,
      maintenanceEquipment: equipment.filter(e => e.status === 'Maintenance').length,
      totalCustomers: customers.length,
      activeRentals: activeRentals.length,
      monthlyRevenue,
      pendingPayments: pendingPaymentsAmount,
      overdueRentals: overdueRentals.length,
      totalMaintenanceCost,
    };
  },

  getRevenueByMonth: () => {
    const payments = PaymentDAO.findAll();
    const monthlyData: Record<string, { revenue: number; rentals: Set<string> }> = {};

    payments.forEach(p => {
      const d = new Date(p.paymentDate);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      if (!monthlyData[key]) {
        monthlyData[key] = { revenue: 0, rentals: new Set() };
      }
      monthlyData[key].revenue += p.amount;
      monthlyData[key].rentals.add(p.rentalId);
    });

    return Object.entries(monthlyData)
      .map(([month, data]) => ({
        month,
        revenue: data.revenue,
        rentals: data.rentals.size,
      }))
      .sort((a, b) => a.month.localeCompare(b.month));
  },

  getMostRentedEquipment: () => {
    const details = RentalDetailDAO.findAll();
    const equipmentStats: Record<string, { count: number; revenue: number }> = {};

    details.forEach(d => {
      if (!equipmentStats[d.equipmentId]) {
        equipmentStats[d.equipmentId] = { count: 0, revenue: 0 };
      }
      equipmentStats[d.equipmentId].count++;
      equipmentStats[d.equipmentId].revenue += d.subtotal;
    });

    return Object.entries(equipmentStats)
      .map(([eqId, stats]) => {
        const eq = EquipmentDAO.findById(eqId);
        return {
          equipmentName: eq?.name || eqId,
          timesRented: stats.count,
          totalRevenue: stats.revenue,
        };
      })
      .sort((a, b) => b.timesRented - a.timesRented);
  },
};

// ==========================================
// RENTAL PRICING SERVICE
// ==========================================
export const RentalPricingService = {
  calculateRate: (days: number, dailyRate: number, weeklyRate: number, monthlyRate: number): { appliedRate: number; subtotal: number; rateType: string } => {
    if (days >= 30) {
      const months = Math.floor(days / 30);
      const remainingDays = days % 30;
      const subtotal = months * monthlyRate + (remainingDays >= 7
        ? Math.floor(remainingDays / 7) * weeklyRate + (remainingDays % 7) * dailyRate
        : remainingDays * dailyRate);
      return { appliedRate: monthlyRate, subtotal, rateType: 'Monthly' };
    } else if (days >= 7) {
      const weeks = Math.floor(days / 7);
      const remainingDays = days % 7;
      const subtotal = weeks * weeklyRate + remainingDays * dailyRate;
      return { appliedRate: weeklyRate, subtotal, rateType: 'Weekly' };
    } else {
      return { appliedRate: dailyRate, subtotal: days * dailyRate, rateType: 'Daily' };
    }
  },

  calculateLateFee: (lateDays: number, dailyRate: number): number => {
    return lateDays * (dailyRate * 1.5);
  },

  calculateFinalAmount: (rentalAmount: number, lateFee: number, damageFee: number): number => {
    return rentalAmount + lateFee + damageFee;
  },

  calculateBalance: (finalAmount: number, deposit: number, totalPayments: number): number => {
    return finalAmount - deposit - totalPayments;
  },
};
