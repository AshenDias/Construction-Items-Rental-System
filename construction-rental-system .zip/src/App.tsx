import { useState, useCallback } from 'react';
import { User } from './types';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import EquipmentManagement from './components/EquipmentManagement';
import CustomerManagement from './components/CustomerManagement';
import RentalManagement from './components/RentalManagement';
import ReturnManagement from './components/ReturnManagement';
import PaymentManagement from './components/PaymentManagement';
import MaintenanceManagement from './components/MaintenanceManagement';
import Reports from './components/Reports';
import {
  LayoutDashboard, Package, Users, FileText, RotateCcw,
  CreditCard, Wrench, BarChart3, LogOut, HardHat, ChevronLeft, ChevronRight,
  Shield, User as UserIcon,
} from 'lucide-react';

type Page = 'dashboard' | 'equipment' | 'customers' | 'rentals' | 'returns' | 'payments' | 'maintenance' | 'reports';

interface NavItem {
  id: Page;
  label: string;
  icon: typeof LayoutDashboard;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'equipment', label: 'Equipment', icon: Package },
  { id: 'customers', label: 'Customers', icon: Users },
  { id: 'rentals', label: 'Rentals', icon: FileText },
  { id: 'returns', label: 'Returns', icon: RotateCcw },
  { id: 'payments', label: 'Payments', icon: CreditCard },
  { id: 'maintenance', label: 'Maintenance', icon: Wrench },
  { id: 'reports', label: 'Reports', icon: BarChart3, adminOnly: true },
];

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const handleLogin = useCallback((user: User) => {
    setCurrentUser(user);
  }, []);

  const handleLogout = useCallback(() => {
    setCurrentUser(null);
    setCurrentPage('dashboard');
  }, []);

  if (!currentUser) {
    return <Login onLogin={handleLogin} />;
  }

  const filteredNav = navItems.filter(item => {
    if (item.adminOnly && currentUser.role !== 'admin') return false;
    return true;
  });

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <Dashboard />;
      case 'equipment': return <EquipmentManagement />;
      case 'customers': return <CustomerManagement />;
      case 'rentals': return <RentalManagement />;
      case 'returns': return <ReturnManagement />;
      case 'payments': return <PaymentManagement />;
      case 'maintenance': return <MaintenanceManagement />;
      case 'reports': return <Reports />;
      default: return <Dashboard />;
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', overflow: 'hidden' }}>
      {/* Sidebar */}
      <div
        className="glass-card"
        style={{
          width: sidebarCollapsed ? '68px' : '240px',
          minWidth: sidebarCollapsed ? '68px' : '240px',
          height: '100%',
          borderRadius: '0 16px 16px 0',
          display: 'flex',
          flexDirection: 'column',
          padding: sidebarCollapsed ? '18px 10px' : '18px 14px',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          overflow: 'hidden',
          position: 'relative',
          zIndex: 10,
        }}
      >
        {/* Logo */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          marginBottom: '28px',
          padding: sidebarCollapsed ? '0 2px' : '0 4px',
          minHeight: '44px',
        }}>
          <div style={{
            width: '40px', height: '40px', minWidth: '40px', borderRadius: '12px',
            background: 'linear-gradient(135deg, rgba(59,130,246,0.25), rgba(139,92,246,0.25))',
            border: '1px solid rgba(255,255,255,0.12)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <HardHat size={22} color="#60a5fa" />
          </div>
          {!sidebarCollapsed && (
            <div>
              <h2 style={{ fontSize: '15px', fontWeight: 800, color: '#f1f5f9', letterSpacing: '-0.02em', whiteSpace: 'nowrap' }}>
                Construct<span style={{ color: '#3b82f6' }}>Rent</span>
              </h2>
              <p style={{ fontSize: '10px', color: 'rgba(255,255,255,0.35)', whiteSpace: 'nowrap' }}>Rental Management</p>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '4px' }}>
          {filteredNav.map(item => (
            <div
              key={item.id}
              className={`sidebar-item ${currentPage === item.id ? 'active' : ''}`}
              onClick={() => setCurrentPage(item.id)}
              title={sidebarCollapsed ? item.label : undefined}
              style={{
                justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
                padding: sidebarCollapsed ? '11px 0' : '11px 16px',
              }}
            >
              <item.icon size={18} style={{ minWidth: '18px' }} />
              {!sidebarCollapsed && <span>{item.label}</span>}
            </div>
          ))}
        </nav>

        {/* Collapse button */}
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          style={{
            background: 'rgba(255,255,255,0.06)',
            border: '1px solid rgba(255,255,255,0.10)',
            borderRadius: '10px',
            padding: '8px',
            cursor: 'pointer',
            color: 'rgba(255,255,255,0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: '12px',
            transition: 'all 0.2s',
          }}
        >
          {sidebarCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>

        {/* User Info */}
        <div style={{
          padding: sidebarCollapsed ? '10px 4px' : '12px 14px',
          borderRadius: '12px',
          background: 'rgba(255,255,255,0.04)',
          border: '1px solid rgba(255,255,255,0.06)',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
        }}>
          <div style={{
            width: '34px', height: '34px', minWidth: '34px', borderRadius: '10px',
            background: currentUser.role === 'admin'
              ? 'linear-gradient(135deg, rgba(139,92,246,0.3), rgba(59,130,246,0.3))'
              : 'linear-gradient(135deg, rgba(16,185,129,0.3), rgba(6,182,212,0.3))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {currentUser.role === 'admin' ? <Shield size={16} color="#a78bfa" /> : <UserIcon size={16} color="#34d399" />}
          </div>
          {!sidebarCollapsed && (
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: '12px', fontWeight: 600, color: '#e2e8f0', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {currentUser.fullName}
              </p>
              <p style={{ fontSize: '10px', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {currentUser.role}
              </p>
            </div>
          )}
          {!sidebarCollapsed && (
            <button
              onClick={handleLogout}
              title="Logout"
              style={{
                background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.25)',
                borderRadius: '8px', padding: '6px', cursor: 'pointer', color: '#f87171',
                display: 'flex', transition: 'all 0.2s',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = 'rgba(239,68,68,0.25)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'rgba(239,68,68,0.12)'; }}
            >
              <LogOut size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div style={{
        flex: 1,
        height: '100%',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
      }}>
        {/* Top Bar */}
        <div style={{
          padding: '14px 28px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid rgba(255,255,255,0.05)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '8px', height: '8px', borderRadius: '50%',
              background: '#10b981',
            }} className="pulse-dot" />
            <span style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)' }}>System Online</span>
          </div>
          <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)' }}>
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>

        {/* Content Area */}
        <div style={{
          flex: 1,
          overflow: 'auto',
          padding: '24px 28px',
        }}>
          {renderPage()}
        </div>
      </div>
    </div>
  );
}
