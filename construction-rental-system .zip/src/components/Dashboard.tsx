import { useState, useEffect } from 'react';
import { DashboardService, RentalDAO, CustomerDAO, EquipmentDAO, PaymentDAO, RentalDetailDAO } from '../store/unifiedStore';
import { DashboardStats, Rental, Payment } from '../types';
import {
  Package, CheckCircle, Truck, Wrench, Users, FileText,
  DollarSign, AlertTriangle, TrendingUp, Clock, Loader2,
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { format } from 'date-fns';

interface RecentRental extends Rental {
  customerName: string;
  equipmentNames: string[];
}

interface RecentPayment extends Payment {
  customerName: string;
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [revenueData, setRevenueData] = useState<{ month: string; revenue: number; rentals: number }[]>([]);
  const [mostRented, setMostRented] = useState<{ equipmentName: string; timesRented: number; totalRevenue: number }[]>([]);
  const [recentRentals, setRecentRentals] = useState<RecentRental[]>([]);
  const [recentPayments, setRecentPayments] = useState<RecentPayment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [statsData, revenueDataResult, mostRentedResult] = await Promise.all([
          DashboardService.getStats(),
          DashboardService.getRevenueByMonth(),
          DashboardService.getMostRentedEquipment(),
        ]);

        setStats(statsData);
        setRevenueData(revenueDataResult);
        setMostRented(mostRentedResult);

        // Load recent rentals
        const rentals = await RentalDAO.findAll();
        const sortedRentals = rentals
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 5);

        const rentalsWithDetails = await Promise.all(
          sortedRentals.map(async r => {
            const customer = await CustomerDAO.findById(r.customerId);
            const details = await RentalDetailDAO.findByRental(r.id);
            const eqNames = await Promise.all(
              details.map(async d => {
                const eq = await EquipmentDAO.findById(d.equipmentId);
                return eq?.name || d.equipmentId;
              })
            );
            return {
              ...r,
              customerName: customer ? `${customer.firstName} ${customer.lastName}` : 'N/A',
              equipmentNames: eqNames,
            };
          })
        );
        setRecentRentals(rentalsWithDetails);

        // Load recent payments
        const payments = await PaymentDAO.findAll();
        const sortedPayments = payments
          .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime())
          .slice(0, 5);

        const paymentsWithDetails = await Promise.all(
          sortedPayments.map(async p => {
            const rental = await RentalDAO.findById(p.rentalId);
            const customer = rental ? await CustomerDAO.findById(rental.customerId) : null;
            return {
              ...p,
              customerName: customer ? `${customer.firstName} ${customer.lastName}` : 'N/A',
            };
          })
        );
        setRecentPayments(paymentsWithDetails);
      } catch (error) {
        console.error('Error loading dashboard:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading || !stats) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading dashboard...</span>
      </div>
    );
  }

  const pieData = [
    { name: 'Available', value: stats.availableEquipment, color: '#10b981' },
    { name: 'Rented', value: stats.rentedEquipment, color: '#3b82f6' },
    { name: 'Maintenance', value: stats.maintenanceEquipment, color: '#f59e0b' },
  ];

  const statCards = [
    { label: 'Total Equipment', value: stats.totalEquipment, icon: Package, color: '#3b82f6', cssClass: 'stat-card-blue' },
    { label: 'Available', value: stats.availableEquipment, icon: CheckCircle, color: '#10b981', cssClass: 'stat-card-green' },
    { label: 'Rented Out', value: stats.rentedEquipment, icon: Truck, color: '#f59e0b', cssClass: 'stat-card-amber' },
    { label: 'In Maintenance', value: stats.maintenanceEquipment, icon: Wrench, color: '#ef4444', cssClass: 'stat-card-red' },
    { label: 'Total Customers', value: stats.totalCustomers, icon: Users, color: '#8b5cf6', cssClass: 'stat-card-purple' },
    { label: 'Active Rentals', value: stats.activeRentals, icon: FileText, color: '#06b6d4', cssClass: 'stat-card-cyan' },
    { label: 'Monthly Revenue', value: `$${stats.monthlyRevenue.toLocaleString()}`, icon: DollarSign, color: '#10b981', cssClass: 'stat-card-green' },
    { label: 'Overdue Rentals', value: stats.overdueRentals, icon: AlertTriangle, color: '#ef4444', cssClass: 'stat-card-red' },
  ];

  return (
    <div style={{ padding: '0', height: '100%', overflowY: 'auto' }}>
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9', letterSpacing: '-0.02em' }}>Dashboard</h1>
        <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>
          Overview of your equipment rental operations
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', marginBottom: '24px' }}>
        {statCards.map((card, i) => (
          <div key={i} className={`glass-card ${card.cssClass}`} style={{ padding: '18px 20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>
                  {card.label}
                </p>
                <p style={{ fontSize: '26px', fontWeight: 800, color: '#f1f5f9', letterSpacing: '-0.02em' }}>
                  {card.value}
                </p>
              </div>
              <div style={{
                width: '40px', height: '40px', borderRadius: '12px',
                background: `${card.color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <card.icon size={20} color={card.color} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '16px', marginBottom: '24px' }}>
        <div className="glass-card" style={{ padding: '22px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
            <div>
              <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9' }}>Revenue Overview</h3>
              <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginTop: '2px' }}>Monthly revenue trend</p>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <TrendingUp size={16} color="#10b981" />
              <span style={{ fontSize: '12px', color: '#34d399', fontWeight: 600 }}>+12.5%</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip
                contentStyle={{
                  background: 'rgba(30, 41, 59, 0.95)',
                  border: '1px solid rgba(255,255,255,0.15)',
                  borderRadius: '12px',
                  color: '#e2e8f0',
                }}
                formatter={(value) => [`$${Number(value).toLocaleString()}`, 'Revenue']}
              />
              <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} fill="url(#colorRevenue)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9', marginBottom: '4px' }}>Equipment Status</h3>
          <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginBottom: '10px' }}>Current fleet distribution</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={4} dataKey="value">
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: 'rgba(30, 41, 59, 0.95)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '12px', color: '#e2e8f0' }} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '16px' }}>
            {pieData.map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: item.color }} />
                <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.6)' }}>{item.name} ({item.value})</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px', marginBottom: '24px' }}>
        <div className="glass-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9', marginBottom: '4px' }}>Most Rented</h3>
          <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginBottom: '14px' }}>Top performing equipment</p>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={mostRented.slice(0, 5)} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis type="category" dataKey="equipmentName" width={100} tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ background: 'rgba(30, 41, 59, 0.95)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '12px', color: '#e2e8f0' }} />
              <Bar dataKey="timesRented" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9', marginBottom: '4px' }}>Recent Rentals</h3>
          <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginBottom: '14px' }}>Latest rental transactions</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {recentRentals.map(r => (
              <div key={r.id} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '10px 12px', borderRadius: '10px', background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.05)',
              }}>
                <div>
                  <p style={{ fontSize: '12px', fontWeight: 600, color: '#e2e8f0' }}>{r.customerName}</p>
                  <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginTop: '2px' }}>
                    {r.equipmentNames.join(', ').substring(0, 30)}...
                  </p>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p style={{ fontSize: '12px', fontWeight: 700, color: '#60a5fa' }}>${r.totalAmount.toLocaleString()}</p>
                  <span className={`badge badge-${r.status.toLowerCase()}`} style={{ fontSize: '9px', padding: '2px 6px' }}>{r.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card" style={{ padding: '22px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
            <Clock size={16} color="#60a5fa" />
            <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9' }}>Recent Payments</h3>
          </div>
          <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginBottom: '14px' }}>Latest payment records</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {recentPayments.map(p => (
              <div key={p.id} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '10px 12px', borderRadius: '10px', background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.05)',
              }}>
                <div>
                  <p style={{ fontSize: '12px', fontWeight: 600, color: '#e2e8f0' }}>{p.customerName}</p>
                  <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginTop: '2px' }}>
                    {format(new Date(p.paymentDate), 'MMM dd, yyyy')} · {p.paymentMethod}
                  </p>
                </div>
                <p style={{ fontSize: '13px', fontWeight: 700, color: '#34d399' }}>
                  +${p.amount.toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
