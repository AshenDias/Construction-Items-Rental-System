import { useState, useEffect, useCallback } from 'react';
import { DashboardService, RentalDAO, CustomerDAO, EquipmentDAO, RentalDetailDAO, PaymentDAO, MaintenanceDAO } from '../store/unifiedStore';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { differenceInDays } from 'date-fns';
import { TrendingUp, DollarSign, AlertTriangle, Wrench, Award, Clock, Loader2, RefreshCw } from 'lucide-react';

interface LateReturn {
  rentalId: string;
  customerName: string;
  equipmentNames: string[];
  daysLate: number;
  lateFee: number;
}

export default function Reports() {
  const [loading, setLoading] = useState(true);
  const [revenueByMonth, setRevenueByMonth] = useState<{ month: string; revenue: number; rentals: number }[]>([]);
  const [mostRented, setMostRented] = useState<{ equipmentName: string; timesRented: number; totalRevenue: number }[]>([]);
  const [lateReturns, setLateReturns] = useState<LateReturn[]>([]);
  const [maintenanceCost, setMaintenanceCost] = useState<{ name: string; cost: number }[]>([]);
  const [revenueByCategory, setRevenueByCategory] = useState<{ name: string; value: number }[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<{ name: string; value: number }[]>([]);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalMaintenance, setTotalMaintenance] = useState(0);
  const [totalRentals, setTotalRentals] = useState(0);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      // Load basic stats
      const [revenueData, mostRentedData, rentals, payments, maintenance, details, equipment] = await Promise.all([
        DashboardService.getRevenueByMonth(),
        DashboardService.getMostRentedEquipment(),
        RentalDAO.findAll(),
        PaymentDAO.findAll(),
        MaintenanceDAO.findAll(),
        RentalDetailDAO.findAll(),
        EquipmentDAO.findAll(),
      ]);

      setRevenueByMonth(revenueData);
      setMostRented(mostRentedData);
      setTotalRevenue(payments.reduce((s, p) => s + p.amount, 0));
      setTotalMaintenance(maintenance.reduce((s, m) => s + m.cost, 0));
      setTotalRentals(rentals.length);

      // Late returns
      const lateRentalData = await Promise.all(
        rentals
          .filter(r => r.status === 'Returned' && r.lateFee > 0)
          .map(async r => {
            const customer = await CustomerDAO.findById(r.customerId);
            const rentalDetails = await RentalDetailDAO.findByRental(r.id);
            const eqNames = await Promise.all(rentalDetails.map(async d => {
              const eq = await EquipmentDAO.findById(d.equipmentId);
              return eq?.name || '';
            }));
            const daysLate = r.actualReturnDate
              ? differenceInDays(new Date(r.actualReturnDate), new Date(r.expectedReturnDate))
              : 0;
            return {
              rentalId: r.id,
              customerName: customer ? `${customer.firstName} ${customer.lastName}` : 'N/A',
              equipmentNames: eqNames,
              daysLate,
              lateFee: r.lateFee,
            };
          })
      );
      setLateReturns(lateRentalData);

      // Maintenance cost by equipment
      const byEquipment: Record<string, number> = {};
      for (const m of maintenance) {
        const eq = await EquipmentDAO.findById(m.equipmentId);
        const name = eq?.name || m.equipmentId;
        byEquipment[name] = (byEquipment[name] || 0) + m.cost;
      }
      setMaintenanceCost(
        Object.entries(byEquipment)
          .map(([name, cost]) => ({ name, cost }))
          .sort((a, b) => b.cost - a.cost)
      );

      // Revenue by category
      const byCategory: Record<string, number> = {};
      for (const d of details) {
        const eq = equipment.find(e => e.id === d.equipmentId);
        const category = eq?.category || 'Other';
        byCategory[category] = (byCategory[category] || 0) + d.subtotal;
      }
      setRevenueByCategory(
        Object.entries(byCategory)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value)
      );

      // Payment methods
      const byMethod: Record<string, number> = {};
      payments.forEach(p => {
        byMethod[p.paymentMethod] = (byMethod[p.paymentMethod] || 0) + p.amount;
      });
      setPaymentMethods(Object.entries(byMethod).map(([name, value]) => ({ name, value })));
    } catch (error) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const PIE_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];
  const tooltipStyle = { background: 'rgba(30, 41, 59, 0.95)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '12px', color: '#e2e8f0' };

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading reports...</span>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', overflowY: 'auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9' }}>Reports & Analytics</h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>Business intelligence and performance metrics</p>
        </div>
        <button className="glass-button" onClick={loadData}><RefreshCw size={16} /> Refresh</button>
      </div>

      {/* Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', marginBottom: '24px' }}>
        <div className="glass-card stat-card-green" style={{ padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', background: 'rgba(16,185,129,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><DollarSign size={20} color="#34d399" /></div>
            <div>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Total Revenue</p>
              <p style={{ fontSize: '22px', fontWeight: 800, color: '#34d399' }}>${totalRevenue.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="glass-card stat-card-red" style={{ padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', background: 'rgba(239,68,68,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Wrench size={20} color="#f87171" /></div>
            <div>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Maintenance Cost</p>
              <p style={{ fontSize: '22px', fontWeight: 800, color: '#f87171' }}>${totalMaintenance.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="glass-card stat-card-blue" style={{ padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', background: 'rgba(59,130,246,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><TrendingUp size={20} color="#60a5fa" /></div>
            <div>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Total Rentals</p>
              <p style={{ fontSize: '22px', fontWeight: 800, color: '#60a5fa' }}>{totalRentals}</p>
            </div>
          </div>
        </div>
        <div className="glass-card stat-card-purple" style={{ padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', background: 'rgba(139,92,246,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><DollarSign size={20} color="#a78bfa" /></div>
            <div>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Net Profit</p>
              <p style={{ fontSize: '22px', fontWeight: 800, color: '#a78bfa' }}>${(totalRevenue - totalMaintenance).toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row 1 */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '16px', marginBottom: '16px' }}>
        <div className="glass-card" style={{ padding: '22px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <TrendingUp size={18} color="#60a5fa" />
            <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9' }}>Revenue Trend</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={revenueByMonth}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value).toLocaleString()}`, 'Revenue']} />
              <Line type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} dot={{ fill: '#3b82f6', r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9', marginBottom: '16px' }}>Revenue by Category</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={revenueByCategory} cx="50%" cy="50%" outerRadius={75} dataKey="value" label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}>
                {revenueByCategory.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value).toLocaleString()}`, 'Revenue']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
        <div className="glass-card" style={{ padding: '22px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <Award size={18} color="#fbbf24" />
            <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9' }}>Most Rented Equipment</h3>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={mostRented.slice(0, 6)}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="equipmentName" angle={-15} textAnchor="end" height={60} tick={{ fontSize: 10 }} />
              <YAxis />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="timesRented" fill="#8b5cf6" radius={[4, 4, 0, 0]} name="Times Rented" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-card" style={{ padding: '22px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <Wrench size={18} color="#f87171" />
            <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9' }}>Maintenance Cost by Equipment</h3>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={maintenanceCost} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value).toLocaleString()}`, 'Cost']} />
              <Bar dataKey="cost" fill="#ef4444" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Payment Methods + Late Returns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '16px', marginBottom: '24px' }}>
        <div className="glass-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9', marginBottom: '16px' }}>Payment Methods</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={paymentMethods} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" paddingAngle={4}>
                {paymentMethods.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value).toLocaleString()}`]} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '8px' }}>
            {paymentMethods.map((pm, i) => (
              <div key={pm.name} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px' }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: PIE_COLORS[i % PIE_COLORS.length] }} />
                <span style={{ color: 'rgba(255,255,255,0.6)', flex: 1 }}>{pm.name}</span>
                <span style={{ fontWeight: 600, color: '#e2e8f0' }}>${pm.value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card" style={{ padding: '22px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <AlertTriangle size={18} color="#f87171" />
            <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#f1f5f9' }}>Late Returns</h3>
          </div>
          {lateReturns.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '30px', color: 'rgba(255,255,255,0.4)' }}>
              <Clock size={32} style={{ opacity: 0.3, marginBottom: '8px' }} />
              <p>No late returns recorded</p>
            </div>
          ) : (
            <table className="glass-table">
              <thead><tr><th>Rental ID</th><th>Customer</th><th>Equipment</th><th>Days Late</th><th>Late Fee</th></tr></thead>
              <tbody>
                {lateReturns.map(lr => (
                  <tr key={lr.rentalId}>
                    <td style={{ fontFamily: 'monospace' }}>{lr.rentalId}</td>
                    <td style={{ fontWeight: 600 }}>{lr.customerName}</td>
                    <td style={{ maxWidth: '160px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{lr.equipmentNames.join(', ')}</td>
                    <td style={{ color: '#f87171', fontWeight: 700 }}>{lr.daysLate} days</td>
                    <td style={{ color: '#fbbf24', fontWeight: 700 }}>${lr.lateFee.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
