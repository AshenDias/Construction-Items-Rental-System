import { useState, useCallback, useEffect } from 'react';
import { RentalDAO, RentalDetailDAO, CustomerDAO, EquipmentDAO, PaymentDAO, RentalPricingService } from '../store/unifiedStore';
import { Rental, RentalDetail, Customer } from '../types';
import { RotateCcw, Search, CheckCircle, Loader2, RefreshCw } from 'lucide-react';
import Modal from './ui/Modal';
import ConfirmDialog from './ui/ConfirmDialog';
import Toast from './ui/Toast';
import { useToast } from '../hooks/useToast';
import { format, differenceInDays } from 'date-fns';

interface ActiveRental extends Rental {
  customer: Customer | null;
  equipmentNames: string[];
  details: RentalDetail[];
  totalPaid: number;
  daysLate: number;
  isOverdue: boolean;
  calculatedLateFee: number;
}

export default function ReturnManagement() {
  const [activeRentals, setActiveRentals] = useState<ActiveRental[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [processRental, setProcessRental] = useState<ActiveRental | null>(null);
  const [damageFee, setDamageFee] = useState('0');
  const [damageNotes, setDamageNotes] = useState('');
  const [confirmReturn, setConfirmReturn] = useState(false);
  const [processing, setProcessing] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const rentals = await RentalDAO.findAll();
      const active = rentals.filter(r => r.status === 'Active');
      
      const withDetails = await Promise.all(active.map(async r => {
        const customer = await CustomerDAO.findById(r.customerId);
        const details = await RentalDetailDAO.findByRental(r.id);
        const eqNames = await Promise.all(details.map(async d => {
          const eq = await EquipmentDAO.findById(d.equipmentId);
          return eq?.name || d.equipmentId;
        }));
        const totalPaid = await PaymentDAO.getTotalByRental(r.id);
        const now = new Date();
        const expected = new Date(r.expectedReturnDate);
        const daysLate = differenceInDays(now, expected);
        const isOverdue = daysLate > 0;

        let lateFee = 0;
        if (isOverdue) {
          details.forEach(d => {
            lateFee += RentalPricingService.calculateLateFee(daysLate, d.dailyRate);
          });
        }

        return {
          ...r,
          customer,
          equipmentNames: eqNames,
          details,
          totalPaid,
          daysLate,
          isOverdue,
          calculatedLateFee: lateFee,
        };
      }));

      setActiveRentals(withDetails);
    } catch (error) {
      console.error('Error loading rentals:', error);
      showToast('Failed to load rentals', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => { loadData(); }, [loadData]);

  const filtered = activeRentals.filter(r => {
    if (!searchTerm) return true;
    const name = r.customer ? `${r.customer.firstName} ${r.customer.lastName}` : '';
    return r.id.toLowerCase().includes(searchTerm.toLowerCase()) || name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const processData = processRental ? {
    ...processRental,
    dmgFee: Number(damageFee) || 0,
    lateFee: processRental.calculatedLateFee,
    finalAmount: processRental.totalAmount + processRental.calculatedLateFee + (Number(damageFee) || 0),
    balance: processRental.totalAmount + processRental.calculatedLateFee + (Number(damageFee) || 0) - processRental.totalPaid,
  } : null;

  const handleProcessReturn = async () => {
    if (!processRental || !processData) return;
    setProcessing(true);

    try {
      const updated: Rental = {
        ...processRental,
        status: 'Returned',
        actualReturnDate: new Date(),
        lateFee: processData.lateFee,
        damageFee: processData.dmgFee,
        notes: processRental.notes + (damageNotes ? ` | Damage: ${damageNotes}` : ''),
      };

      await RentalDAO.save(updated);

      // Set equipment back to Available
      for (const d of processRental.details) {
        await EquipmentDAO.updateStatus(d.equipmentId, 'Available');
      }

      await loadData();
      setProcessRental(null);
      setConfirmReturn(false);
      setDamageFee('0');
      setDamageNotes('');
      showToast('Return processed successfully! Equipment set to Available.', 'success');
    } catch (error) {
      console.error('Error processing return:', error);
      showToast('Failed to process return', 'error');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading rentals...</span>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {toast.visible && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9' }}>Return Management</h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>Process equipment returns, calculate late fees and damage charges</p>
        </div>
        <button className="glass-button" onClick={loadData}><RefreshCw size={16} /> Refresh</button>
      </div>

      <div className="glass-card" style={{ padding: '16px 20px', marginBottom: '16px' }}>
        <div style={{ position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
          <input className="glass-input" style={{ paddingLeft: '36px' }} placeholder="Search active rentals..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
      </div>

      <div className="glass-card" style={{ flex: 1, overflow: 'auto', padding: '2px' }}>
        <table className="glass-table">
          <thead>
            <tr>
              <th>Rental ID</th><th>Customer</th><th>Equipment</th><th>Start Date</th>
              <th>Due Date</th><th>Days Late</th><th>Total</th><th>Paid</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={9} style={{ textAlign: 'center', padding: '40px', color: 'rgba(255,255,255,0.4)' }}>
                <CheckCircle size={40} style={{ marginBottom: '10px', opacity: 0.3 }} /><p>No active rentals to return</p>
              </td></tr>
            ) : (
              filtered.map(r => (
                <tr key={r.id}>
                  <td style={{ fontFamily: 'monospace', fontWeight: 600 }}>{r.id}</td>
                  <td style={{ fontWeight: 600, color: '#e2e8f0' }}>{r.customer ? `${r.customer.firstName} ${r.customer.lastName}` : 'N/A'}</td>
                  <td style={{ maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.equipmentNames.join(', ')}</td>
                  <td>{format(new Date(r.rentalDate), 'MMM dd')}</td>
                  <td>{format(new Date(r.expectedReturnDate), 'MMM dd')}</td>
                  <td>
                    {r.isOverdue ? (
                      <span style={{ color: '#f87171', fontWeight: 700 }}>{r.daysLate} days</span>
                    ) : (
                      <span style={{ color: '#34d399' }}>On time</span>
                    )}
                  </td>
                  <td style={{ fontWeight: 600 }}>${r.totalAmount.toLocaleString()}</td>
                  <td style={{ color: '#34d399' }}>${r.totalPaid.toLocaleString()}</td>
                  <td>
                    <button className="glass-button glass-button-success" style={{ padding: '6px 12px' }} onClick={() => { setProcessRental(r); setDamageFee('0'); setDamageNotes(''); }}>
                      <RotateCcw size={14} /> Return
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {processRental && processData && (
        <Modal title={`Process Return — ${processRental.id}`} onClose={() => setProcessRental(null)} width="600px">
          <div style={{ marginBottom: '18px' }}>
            <div style={{ padding: '14px', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', marginBottom: '14px' }}>
              <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)', marginBottom: '4px' }}>Customer</p>
              <p style={{ fontSize: '15px', fontWeight: 600, color: '#e2e8f0' }}>
                {processData.customer ? `${processData.customer.firstName} ${processData.customer.lastName}` : 'N/A'}
              </p>
              <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginTop: '4px' }}>
                Equipment: {processData.equipmentNames.join(', ')}
              </p>
            </div>

            {processData.daysLate > 0 && (
              <div style={{ padding: '14px', borderRadius: '12px', background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', marginBottom: '14px' }}>
                <p style={{ fontSize: '13px', color: '#f87171', fontWeight: 700 }}>⚠️ {processData.daysLate} days overdue</p>
                <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)', marginTop: '4px' }}>Late fee: 1.5× daily rate per day</p>
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' }}>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Damage Fee ($)</label>
                <input className="glass-input" type="number" value={damageFee} onChange={e => setDamageFee(e.target.value)} min="0" />
              </div>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Damage Notes</label>
                <input className="glass-input" value={damageNotes} onChange={e => setDamageNotes(e.target.value)} placeholder="Describe any damage..." />
              </div>
            </div>

            <div style={{ padding: '16px', borderRadius: '12px', background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.15)' }}>
              <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#60a5fa', marginBottom: '10px' }}>Final Settlement</h4>
              <div style={{ fontSize: '13px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'rgba(255,255,255,0.6)' }}>Rental Amount</span>
                  <span style={{ color: '#e2e8f0' }}>${processRental.totalAmount.toLocaleString()}</span>
                </div>
                {processData.lateFee > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#f87171' }}>Late Fee ({processData.daysLate} days)</span>
                    <span style={{ color: '#f87171', fontWeight: 600 }}>+${processData.lateFee.toLocaleString()}</span>
                  </div>
                )}
                {processData.dmgFee > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#fbbf24' }}>Damage Fee</span>
                    <span style={{ color: '#fbbf24', fontWeight: 600 }}>+${processData.dmgFee.toLocaleString()}</span>
                  </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '6px' }}>
                  <span style={{ color: 'rgba(255,255,255,0.6)' }}>Total Due</span>
                  <span style={{ color: '#e2e8f0', fontWeight: 700 }}>${processData.finalAmount.toLocaleString()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'rgba(255,255,255,0.6)' }}>Already Paid</span>
                  <span style={{ color: '#34d399' }}>-${processData.totalPaid.toLocaleString()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '6px', fontSize: '16px' }}>
                  <span style={{ fontWeight: 700, color: '#e2e8f0' }}>Balance</span>
                  <span style={{ fontWeight: 800, color: processData.balance > 0 ? '#f87171' : '#34d399' }}>${processData.balance.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
            <button className="glass-button" onClick={() => setProcessRental(null)}>Cancel</button>
            <button className="glass-button glass-button-success" onClick={() => setConfirmReturn(true)} disabled={processing}>
              {processing ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />} Process Return
            </button>
          </div>
        </Modal>
      )}

      {confirmReturn && (
        <ConfirmDialog
          title="Confirm Return"
          message="Process this return? Equipment will be set back to Available status."
          onConfirm={handleProcessReturn}
          onCancel={() => setConfirmReturn(false)}
          confirmText="Confirm Return"
        />
      )}
    </div>
  );
}
