import { useState } from 'react';
import { HardHat, Settings, Smartphone, Monitor, Cloud, CheckCircle, Copy, ExternalLink } from 'lucide-react';

interface SetupScreenProps {
  onContinueOffline: () => void;
}

export default function SetupScreen({ onContinueOffline }: SetupScreenProps) {
  const [copied, setCopied] = useState(false);

  const configTemplate = `const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};`;

  const handleCopy = () => {
    navigator.clipboard.writeText(configTemplate);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{
      width: '100%',
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #1a2332 100%)',
      padding: '20px',
    }}>
      <div style={{ maxWidth: '700px', width: '100%' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{
            width: '72px', height: '72px', borderRadius: '20px',
            background: 'linear-gradient(135deg, rgba(59,130,246,0.25), rgba(139,92,246,0.25))',
            border: '1px solid rgba(255,255,255,0.15)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 18px',
          }}>
            <HardHat size={36} color="#60a5fa" />
          </div>
          <h1 style={{ fontSize: '28px', fontWeight: 800, color: '#f1f5f9' }}>
            ConstructRent<span style={{ color: '#3b82f6' }}>Pro</span>
          </h1>
          <p style={{ fontSize: '14px', color: 'rgba(255,255,255,0.5)', marginTop: '8px' }}>
            Equipment Rental Management System
          </p>
        </div>

        {/* Setup Card */}
        <div className="glass-card" style={{ padding: '32px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
            <Settings size={24} color="#60a5fa" />
            <h2 style={{ fontSize: '18px', fontWeight: 700, color: '#f1f5f9' }}>Firebase Setup Required</h2>
          </div>

          <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', lineHeight: '1.6', marginBottom: '24px' }}>
            To enable <strong style={{ color: '#60a5fa' }}>real-time sync</strong> between your PC and Android phone, 
            you need to set up Firebase. This takes about 5 minutes.
          </p>

          {/* Features */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', marginBottom: '28px' }}>
            <div style={{ padding: '16px', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', textAlign: 'center' }}>
              <Monitor size={24} color="#3b82f6" style={{ marginBottom: '8px' }} />
              <p style={{ fontSize: '12px', fontWeight: 600, color: '#e2e8f0' }}>PC Desktop</p>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)' }}>Full management</p>
            </div>
            <div style={{ padding: '16px', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', textAlign: 'center' }}>
              <Cloud size={24} color="#8b5cf6" style={{ marginBottom: '8px' }} />
              <p style={{ fontSize: '12px', fontWeight: 600, color: '#e2e8f0' }}>Cloud Sync</p>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)' }}>Real-time updates</p>
            </div>
            <div style={{ padding: '16px', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', textAlign: 'center' }}>
              <Smartphone size={24} color="#10b981" style={{ marginBottom: '8px' }} />
              <p style={{ fontSize: '12px', fontWeight: 600, color: '#e2e8f0' }}>Mobile App</p>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)' }}>View on the go</p>
            </div>
          </div>

          {/* Instructions */}
          <div style={{ background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: '12px', padding: '20px', marginBottom: '24px' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 700, color: '#60a5fa', marginBottom: '16px' }}>Setup Instructions</h3>
            <ol style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: '2', paddingLeft: '20px' }}>
              <li>Go to <a href="https://console.firebase.google.com/" target="_blank" rel="noopener noreferrer" style={{ color: '#60a5fa' }}>Firebase Console <ExternalLink size={12} style={{ display: 'inline' }} /></a></li>
              <li>Create a new project (name: "constructrent-pro")</li>
              <li>Add a Web App (click &lt;/&gt; icon)</li>
              <li>Copy the <code style={{ background: 'rgba(255,255,255,0.1)', padding: '2px 6px', borderRadius: '4px' }}>firebaseConfig</code> object</li>
              <li>Enable Firestore Database (Build → Firestore → Create)</li>
              <li>Enable Email/Password Auth (Build → Authentication)</li>
              <li>Paste config in <code style={{ background: 'rgba(255,255,255,0.1)', padding: '2px 6px', borderRadius: '4px' }}>src/firebase/config.ts</code></li>
            </ol>
          </div>

          {/* Config template */}
          <div style={{ marginBottom: '24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <span style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)' }}>Config Template:</span>
              <button 
                onClick={handleCopy}
                style={{
                  background: 'rgba(255,255,255,0.08)',
                  border: '1px solid rgba(255,255,255,0.12)',
                  borderRadius: '6px',
                  padding: '4px 10px',
                  fontSize: '11px',
                  color: copied ? '#34d399' : 'rgba(255,255,255,0.6)',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                }}
              >
                {copied ? <CheckCircle size={12} /> : <Copy size={12} />}
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <pre style={{
              background: 'rgba(0,0,0,0.3)',
              borderRadius: '8px',
              padding: '14px',
              fontSize: '11px',
              color: 'rgba(255,255,255,0.6)',
              overflow: 'auto',
              fontFamily: 'monospace',
            }}>
              {configTemplate}
            </pre>
          </div>

          {/* Actions */}
          <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
            <button 
              className="glass-button"
              onClick={onContinueOffline}
              style={{ padding: '12px 24px' }}
            >
              Continue Offline (Demo Mode)
            </button>
            <a
              href="https://console.firebase.google.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="glass-button glass-button-primary"
              style={{ padding: '12px 24px', textDecoration: 'none' }}
            >
              Open Firebase Console
            </a>
          </div>

          <p style={{ textAlign: 'center', fontSize: '11px', color: 'rgba(255,255,255,0.35)', marginTop: '16px' }}>
            Offline mode uses browser storage. Data won't sync between devices.
          </p>
        </div>
      </div>
    </div>
  );
}
