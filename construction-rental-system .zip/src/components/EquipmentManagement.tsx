import { useState, useMemo, useCallback, useEffect } from 'react';
import { EquipmentDAO } from '../store/unifiedStore';
import { Equipment, EquipmentStatus } from '../types';
import { Plus, Search, Edit2, Trash2, Filter, Package, Loader2, RefreshCw } from 'lucide-react';
import Modal from './ui/Modal';
import ConfirmDialog from './ui/ConfirmDialog';
import Toast from './ui/Toast';
import { useToast } from '../hooks/useToast';

const CATEGORIES = ['Excavator', 'Bulldozer', 'Crane', 'Loader', 'Backhoe', 'Compactor', 'Concrete Pump', 'Skid Steer', 'Milling Machine', 'Generator', 'Forklift', 'Dump Truck'];

interface EquipmentFormData {
  name: string;
  category: string;
  brand: string;
  model: string;
  serialNumber: string;
  status: EquipmentStatus;
  dailyRate: string;
  weeklyRate: string;
  monthlyRate: string;
  purchaseCost: string;
  description: string;
}

const emptyForm: EquipmentFormData = {
  name: '', category: CATEGORIES[0], brand: '', model: '', serialNumber: '',
  status: 'Available', dailyRate: '', weeklyRate: '', monthlyRate: '',
  purchaseCost: '', description: '',
};

export default function EquipmentManagement() {
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<EquipmentFormData>(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState<Equipment | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await EquipmentDAO.findAll();
      setEquipment(data);
    } catch (error) {
      console.error('Error loading equipment:', error);
      showToast('Failed to load equipment', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const filtered = useMemo(() => {
    return equipment.filter(e => {
      const matchSearch = searchTerm === '' ||
        e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchStatus = filterStatus === 'All' || e.status === filterStatus;
      const matchCategory = filterCategory === 'All' || e.category === filterCategory;
      return matchSearch && matchStatus && matchCategory;
    });
  }, [equipment, searchTerm, filterStatus, filterCategory]);

  const openAdd = () => {
    setEditingId(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (eq: Equipment) => {
    setEditingId(eq.id);
    setForm({
      name: eq.name, category: eq.category, brand: eq.brand, model: eq.model,
      serialNumber: eq.serialNumber, status: eq.status,
      dailyRate: String(eq.dailyRate), weeklyRate: String(eq.weeklyRate),
      monthlyRate: String(eq.monthlyRate), purchaseCost: String(eq.purchaseCost),
      description: eq.description,
    });
    setShowForm(true);
  };

  const validateForm = (): boolean => {
    if (!form.name.trim()) { showToast('Equipment name is required', 'error'); return false; }
    if (!form.brand.trim()) { showToast('Brand is required', 'error'); return false; }
    if (!form.model.trim()) { showToast('Model is required', 'error'); return false; }
    if (!form.serialNumber.trim()) { showToast('Serial number is required', 'error'); return false; }
    if (!form.dailyRate || isNaN(Number(form.dailyRate)) || Number(form.dailyRate) <= 0) {
      showToast('Daily rate must be a positive number', 'error'); return false;
    }
    if (!form.weeklyRate || isNaN(Number(form.weeklyRate)) || Number(form.weeklyRate) <= 0) {
      showToast('Weekly rate must be a positive number', 'error'); return false;
    }
    if (!form.monthlyRate || isNaN(Number(form.monthlyRate)) || Number(form.monthlyRate) <= 0) {
      showToast('Monthly rate must be a positive number', 'error'); return false;
    }
    return true;
  };

  const handleSave = async () => {
    if (!validateForm()) return;
    setSaving(true);

    try {
      // Check duplicate serial number
      const allEquipment = await EquipmentDAO.findAll();
      const duplicate = allEquipment.find(e => 
        e.serialNumber === form.serialNumber.trim() && e.id !== editingId
      );
      if (duplicate) {
        showToast('Serial number already exists', 'error');
        setSaving(false);
        return;
      }

      const existing = editingId ? await EquipmentDAO.findById(editingId) : null;
      const eq: Equipment = {
        id: editingId || await EquipmentDAO.generateId(),
        name: form.name.trim(),
        category: form.category,
        brand: form.brand.trim(),
        model: form.model.trim(),
        serialNumber: form.serialNumber.trim(),
        status: form.status,
        dailyRate: Number(form.dailyRate),
        weeklyRate: Number(form.weeklyRate),
        monthlyRate: Number(form.monthlyRate),
        purchaseDate: existing?.purchaseDate || new Date(),
        purchaseCost: Number(form.purchaseCost) || 0,
        description: form.description.trim(),
        createdAt: existing?.createdAt || new Date(),
      };

      await EquipmentDAO.save(eq);
      await loadData();
      setShowForm(false);
      showToast(editingId ? 'Equipment updated successfully' : 'Equipment added successfully', 'success');
    } catch (error) {
      console.error('Error saving equipment:', error);
      showToast('Failed to save equipment', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (deleteTarget) {
      if (deleteTarget.status === 'Rented') {
        showToast('Cannot delete rented equipment', 'error');
        setDeleteTarget(null);
        return;
      }
      try {
        await EquipmentDAO.delete(deleteTarget.id);
        await loadData();
        setDeleteTarget(null);
        showToast('Equipment deleted successfully', 'success');
      } catch (error) {
        console.error('Error deleting equipment:', error);
        showToast('Failed to delete equipment', 'error');
      }
    }
  };

  const updateField = (field: keyof EquipmentFormData, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const statusBadge = (status: EquipmentStatus) => {
    const cls = status === 'Available' ? 'badge-available' : status === 'Rented' ? 'badge-rented' : 'badge-maintenance';
    return <span className={`badge ${cls}`}>{status}</span>;
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading equipment...</span>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {toast.visible && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9' }}>Equipment Management</h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>Manage your construction equipment fleet</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="glass-button" onClick={loadData} title="Refresh">
            <RefreshCw size={16} />
          </button>
          <button className="glass-button glass-button-primary" onClick={openAdd}>
            <Plus size={16} /> Add Equipment
          </button>
        </div>
      </div>

      <div className="glass-card" style={{ padding: '16px 20px', marginBottom: '16px', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: '200px' }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
          <input className="glass-input" style={{ paddingLeft: '36px' }} placeholder="Search by name, brand, serial number..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Filter size={14} color="rgba(255,255,255,0.5)" />
          <select className="glass-select" style={{ width: '140px' }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="All">All Status</option>
            <option value="Available">Available</option>
            <option value="Rented">Rented</option>
            <option value="Maintenance">Maintenance</option>
          </select>
          <select className="glass-select" style={{ width: '160px' }} value={filterCategory} onChange={e => setFilterCategory(e.target.value)}>
            <option value="All">All Categories</option>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>

      <div className="glass-card" style={{ flex: 1, overflow: 'auto', padding: '2px' }}>
        <table className="glass-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Category</th>
              <th>Brand / Model</th>
              <th>Serial No.</th>
              <th>Daily Rate</th>
              <th>Weekly Rate</th>
              <th>Monthly Rate</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={10} style={{ textAlign: 'center', padding: '40px', color: 'rgba(255,255,255,0.4)' }}>
                  <Package size={40} style={{ marginBottom: '10px', opacity: 0.3 }} />
                  <p>No equipment found</p>
                </td>
              </tr>
            ) : (
              filtered.map(eq => (
                <tr key={eq.id}>
                  <td style={{ fontFamily: 'monospace', color: 'rgba(255,255,255,0.5)' }}>{eq.id}</td>
                  <td style={{ fontWeight: 600, color: '#e2e8f0' }}>{eq.name}</td>
                  <td>{eq.category}</td>
                  <td>{eq.brand} {eq.model}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: '11px' }}>{eq.serialNumber}</td>
                  <td style={{ color: '#34d399', fontWeight: 600 }}>${eq.dailyRate.toLocaleString()}</td>
                  <td style={{ color: '#60a5fa', fontWeight: 600 }}>${eq.weeklyRate.toLocaleString()}</td>
                  <td style={{ color: '#a78bfa', fontWeight: 600 }}>${eq.monthlyRate.toLocaleString()}</td>
                  <td>{statusBadge(eq.status)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button className="glass-button" style={{ padding: '6px 10px' }} onClick={() => openEdit(eq)} title="Edit">
                        <Edit2 size={14} />
                      </button>
                      <button className="glass-button glass-button-danger" style={{ padding: '6px 10px' }} onClick={() => setDeleteTarget(eq)} title="Delete">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: '12px', fontSize: '12px', color: 'rgba(255,255,255,0.4)' }}>
        Showing {filtered.length} of {equipment.length} equipment
      </div>

      {showForm && (
        <Modal title={editingId ? 'Edit Equipment' : 'Add New Equipment'} onClose={() => setShowForm(false)} width="620px">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Equipment Name *</label>
              <input className="glass-input" value={form.name} onChange={e => updateField('name', e.target.value)} placeholder="e.g., CAT 320 Excavator" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Category *</label>
              <select className="glass-select" value={form.category} onChange={e => updateField('category', e.target.value)}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Status</label>
              <select className="glass-select" value={form.status} onChange={e => updateField('status', e.target.value)}>
                <option value="Available">Available</option>
                <option value="Rented">Rented</option>
                <option value="Maintenance">Maintenance</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Brand *</label>
              <input className="glass-input" value={form.brand} onChange={e => updateField('brand', e.target.value)} placeholder="e.g., Caterpillar" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Model *</label>
              <input className="glass-input" value={form.model} onChange={e => updateField('model', e.target.value)} placeholder="e.g., 320 GC" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Serial Number *</label>
              <input className="glass-input" value={form.serialNumber} onChange={e => updateField('serialNumber', e.target.value)} placeholder="Unique serial number" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Purchase Cost ($)</label>
              <input className="glass-input" type="number" value={form.purchaseCost} onChange={e => updateField('purchaseCost', e.target.value)} placeholder="0" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Daily Rate ($) *</label>
              <input className="glass-input" type="number" value={form.dailyRate} onChange={e => updateField('dailyRate', e.target.value)} placeholder="0" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Weekly Rate ($) *</label>
              <input className="glass-input" type="number" value={form.weeklyRate} onChange={e => updateField('weeklyRate', e.target.value)} placeholder="0" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Monthly Rate ($) *</label>
              <input className="glass-input" type="number" value={form.monthlyRate} onChange={e => updateField('monthlyRate', e.target.value)} placeholder="0" />
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Description</label>
              <textarea className="glass-textarea" value={form.description} onChange={e => updateField('description', e.target.value)} placeholder="Equipment description..." />
            </div>
          </div>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '22px' }}>
            <button className="glass-button" onClick={() => setShowForm(false)}>Cancel</button>
            <button className="glass-button glass-button-primary" onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 size={16} className="animate-spin" /> : null}
              {editingId ? 'Update Equipment' : 'Add Equipment'}
            </button>
          </div>
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete Equipment"
          message={`Are you sure you want to delete "${deleteTarget.name}"? This action cannot be undone.`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          confirmText="Delete"
          danger
        />
      )}
    </div>
  );
}
