import { useState, useMemo, useCallback, useEffect } from 'react';
import { CustomerDAO, RentalDAO, EquipmentDAO, RentalDetailDAO, PaymentDAO } from '../store/unifiedStore';
import { Customer, Rental } from '../types';
import { Plus, Search, Edit2, Trash2, Users, Eye, Loader2, RefreshCw } from 'lucide-react';
import Modal from './ui/Modal';
import ConfirmDialog from './ui/ConfirmDialog';
import Toast from './ui/Toast';
import { useToast } from '../hooks/useToast';
import { format } from 'date-fns';

interface CustomerFormData {
  firstName: string; lastName: string; company: string; email: string;
  phone: string; address: string; city: string; idNumber: string; notes: string;
}

const emptyForm: CustomerFormData = {
  firstName: '', lastName: '', company: '', email: '', phone: '',
  address: '', city: '', idNumber: '', notes: '',
};

interface RentalWithDetails extends Rental {
  equipmentNames: string[];
  totalPaid: number;
}

export default function CustomerManagement() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<CustomerFormData>(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState<Customer | null>(null);
  const [viewCustomer, setViewCustomer] = useState<Customer | null>(null);
  const [customerHistory, setCustomerHistory] = useState<RentalWithDetails[]>([]);
  const [saving, setSaving] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await CustomerDAO.findAll();
      setCustomers(data);
    } catch (error) {
      console.error('Error loading customers:', error);
      showToast('Failed to load customers', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => { loadData(); }, [loadData]);

  const loadCustomerHistory = useCallback(async (customer: Customer) => {
    try {
      const rentals = await RentalDAO.findByCustomer(customer.id);
      const withDetails = await Promise.all(rentals.map(async r => {
        const details = await RentalDetailDAO.findByRental(r.id);
        const eqNames = await Promise.all(details.map(async d => {
          const eq = await EquipmentDAO.findById(d.equipmentId);
          return eq?.name || d.equipmentId;
        }));
        const totalPaid = await PaymentDAO.getTotalByRental(r.id);
        return { ...r, equipmentNames: eqNames, totalPaid };
      }));
      setCustomerHistory(withDetails.sort((a, b) => new Date(b.rentalDate).getTime() - new Date(a.rentalDate).getTime()));
      setViewCustomer(customer);
    } catch (error) {
      console.error('Error loading customer history:', error);
    }
  }, []);

  const filtered = useMemo(() => {
    return customers.filter(c => {
      const term = searchTerm.toLowerCase();
      return term === '' ||
        c.firstName.toLowerCase().includes(term) || c.lastName.toLowerCase().includes(term) ||
        c.company.toLowerCase().includes(term) || c.email.toLowerCase().includes(term) ||
        c.phone.includes(term) || c.id.toLowerCase().includes(term);
    });
  }, [customers, searchTerm]);

  const openAdd = () => { setEditingId(null); setForm(emptyForm); setShowForm(true); };
  const openEdit = (c: Customer) => {
    setEditingId(c.id);
    setForm({ firstName: c.firstName, lastName: c.lastName, company: c.company, email: c.email,
      phone: c.phone, address: c.address, city: c.city, idNumber: c.idNumber, notes: c.notes });
    setShowForm(true);
  };

  const validateForm = (): boolean => {
    if (!form.firstName.trim()) { showToast('First name is required', 'error'); return false; }
    if (!form.lastName.trim()) { showToast('Last name is required', 'error'); return false; }
    if (!form.email.trim()) { showToast('Email is required', 'error'); return false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) { showToast('Invalid email format', 'error'); return false; }
    if (!form.phone.trim()) { showToast('Phone is required', 'error'); return false; }
    return true;
  };

  const handleSave = async () => {
    if (!validateForm()) return;
    setSaving(true);
    try {
      const existing = await CustomerDAO.findByEmail(form.email.trim());
      if (existing && existing.id !== editingId) { showToast('Email already exists', 'error'); setSaving(false); return; }
      
      const existingCustomer = editingId ? await CustomerDAO.findById(editingId) : null;
      const customer: Customer = {
        id: editingId || await CustomerDAO.generateId(),
        firstName: form.firstName.trim(), lastName: form.lastName.trim(), company: form.company.trim(),
        email: form.email.trim(), phone: form.phone.trim(), address: form.address.trim(),
        city: form.city.trim(), idNumber: form.idNumber.trim(), notes: form.notes.trim(),
        createdAt: existingCustomer?.createdAt || new Date(),
      };
      await CustomerDAO.save(customer);
      await loadData();
      setShowForm(false);
      showToast(editingId ? 'Customer updated successfully' : 'Customer added successfully', 'success');
    } catch (error) {
      console.error('Error saving customer:', error);
      showToast('Failed to save customer', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (deleteTarget) {
      try {
        const rentals = await RentalDAO.findByCustomer(deleteTarget.id);
        const activeRentals = rentals.filter(r => r.status === 'Active');
        if (activeRentals.length > 0) { showToast('Cannot delete customer with active rentals', 'error'); setDeleteTarget(null); return; }
        await CustomerDAO.delete(deleteTarget.id);
        await loadData();
        setDeleteTarget(null);
        showToast('Customer deleted successfully', 'success');
      } catch (error) {
        console.error('Error deleting customer:', error);
        showToast('Failed to delete customer', 'error');
      }
    }
  };

  const updateField = (field: keyof CustomerFormData, value: string) => setForm(prev => ({ ...prev, [field]: value }));

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading customers...</span>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {toast.visible && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9' }}>Customer Management</h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>Manage your customer database</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="glass-button" onClick={loadData}><RefreshCw size={16} /></button>
          <button className="glass-button glass-button-primary" onClick={openAdd}><Plus size={16} /> Add Customer</button>
        </div>
      </div>

      <div className="glass-card" style={{ padding: '16px 20px', marginBottom: '16px' }}>
        <div style={{ position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
          <input className="glass-input" style={{ paddingLeft: '36px' }} placeholder="Search by name, company, email, phone..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
      </div>

      <div className="glass-card" style={{ flex: 1, overflow: 'auto', padding: '2px' }}>
        <table className="glass-table">
          <thead><tr><th>ID</th><th>Name</th><th>Company</th><th>Email</th><th>Phone</th><th>City</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={7} style={{ textAlign: 'center', padding: '40px', color: 'rgba(255,255,255,0.4)' }}>
                <Users size={40} style={{ marginBottom: '10px', opacity: 0.3 }} /><p>No customers found</p>
              </td></tr>
            ) : (
              filtered.map(c => (
                <tr key={c.id}>
                  <td style={{ fontFamily: 'monospace', color: 'rgba(255,255,255,0.5)' }}>{c.id}</td>
                  <td style={{ fontWeight: 600, color: '#e2e8f0' }}>{c.firstName} {c.lastName}</td>
                  <td>{c.company || '—'}</td>
                  <td style={{ color: '#60a5fa' }}>{c.email}</td>
                  <td>{c.phone}</td>
                  <td>{c.city || '—'}</td>
                  <td>
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button className="glass-button" style={{ padding: '6px 10px' }} onClick={() => loadCustomerHistory(c)}><Eye size={14} /></button>
                      <button className="glass-button" style={{ padding: '6px 10px' }} onClick={() => openEdit(c)}><Edit2 size={14} /></button>
                      <button className="glass-button glass-button-danger" style={{ padding: '6px 10px' }} onClick={() => setDeleteTarget(c)}><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <div style={{ marginTop: '12px', fontSize: '12px', color: 'rgba(255,255,255,0.4)' }}>Showing {filtered.length} of {customers.length} customers</div>

      {showForm && (
        <Modal title={editingId ? 'Edit Customer' : 'Add New Customer'} onClose={() => setShowForm(false)} width="580px">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>First Name *</label><input className="glass-input" value={form.firstName} onChange={e => updateField('firstName', e.target.value)} /></div>
            <div><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Last Name *</label><input className="glass-input" value={form.lastName} onChange={e => updateField('lastName', e.target.value)} /></div>
            <div style={{ gridColumn: '1 / -1' }}><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Company</label><input className="glass-input" value={form.company} onChange={e => updateField('company', e.target.value)} /></div>
            <div><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Email *</label><input className="glass-input" type="email" value={form.email} onChange={e => updateField('email', e.target.value)} /></div>
            <div><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Phone *</label><input className="glass-input" value={form.phone} onChange={e => updateField('phone', e.target.value)} /></div>
            <div><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Address</label><input className="glass-input" value={form.address} onChange={e => updateField('address', e.target.value)} /></div>
            <div><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>City</label><input className="glass-input" value={form.city} onChange={e => updateField('city', e.target.value)} /></div>
            <div style={{ gridColumn: '1 / -1' }}><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>ID Number</label><input className="glass-input" value={form.idNumber} onChange={e => updateField('idNumber', e.target.value)} placeholder="e.g., Driver's license" /></div>
            <div style={{ gridColumn: '1 / -1' }}><label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Notes</label><textarea className="glass-textarea" value={form.notes} onChange={e => updateField('notes', e.target.value)} /></div>
          </div>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '22px' }}>
            <button className="glass-button" onClick={() => setShowForm(false)}>Cancel</button>
            <button className="glass-button glass-button-primary" onClick={handleSave} disabled={saving}>{saving ? <Loader2 size={16} className="animate-spin" /> : null}{editingId ? 'Update' : 'Add Customer'}</button>
          </div>
        </Modal>
      )}

      {viewCustomer && (
        <Modal title={`Rental History — ${viewCustomer.firstName} ${viewCustomer.lastName}`} onClose={() => setViewCustomer(null)} width="700px">
          <div style={{ marginBottom: '16px', padding: '14px', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '13px' }}>
              <div><span style={{ color: 'rgba(255,255,255,0.5)' }}>Company:</span> <span style={{ color: '#e2e8f0' }}>{viewCustomer.company || '—'}</span></div>
              <div><span style={{ color: 'rgba(255,255,255,0.5)' }}>Email:</span> <span style={{ color: '#60a5fa' }}>{viewCustomer.email}</span></div>
              <div><span style={{ color: 'rgba(255,255,255,0.5)' }}>Phone:</span> <span style={{ color: '#e2e8f0' }}>{viewCustomer.phone}</span></div>
              <div><span style={{ color: 'rgba(255,255,255,0.5)' }}>City:</span> <span style={{ color: '#e2e8f0' }}>{viewCustomer.city || '—'}</span></div>
            </div>
          </div>
          {customerHistory.length === 0 ? (
            <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.4)', padding: '30px' }}>No rental history found</p>
          ) : (
            <div style={{ maxHeight: '400px', overflow: 'auto' }}>
              <table className="glass-table">
                <thead><tr><th>Rental ID</th><th>Date</th><th>Equipment</th><th>Amount</th><th>Paid</th><th>Status</th></tr></thead>
                <tbody>
                  {customerHistory.map(r => (
                    <tr key={r.id}>
                      <td style={{ fontFamily: 'monospace' }}>{r.id}</td>
                      <td>{format(new Date(r.rentalDate), 'MMM dd, yyyy')}</td>
                      <td style={{ maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.equipmentNames.join(', ')}</td>
                      <td style={{ fontWeight: 600 }}>${r.totalAmount.toLocaleString()}</td>
                      <td style={{ color: '#34d399' }}>${r.totalPaid.toLocaleString()}</td>
                      <td><span className={`badge badge-${r.status.toLowerCase()}`}>{r.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog title="Delete Customer" message={`Delete "${deleteTarget.firstName} ${deleteTarget.lastName}"?`} onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} confirmText="Delete" danger />
      )}
    </div>
  );
}
