import { useState, useMemo, useCallback, useEffect } from 'react';
import { MaintenanceDAO, EquipmentDAO } from '../store/unifiedStore';
import { Maintenance, MaintenanceStatus, Equipment } from '../types';
import { Plus, Search, Edit2, Trash2, Wrench, Filter, Loader2, RefreshCw } from 'lucide-react';
import Modal from './ui/Modal';
import ConfirmDialog from './ui/ConfirmDialog';
import Toast from './ui/Toast';
import { useToast } from '../hooks/useToast';
import { format } from 'date-fns';

interface MaintenanceFormData {
  equipmentId: string; description: string; startDate: string; endDate: string;
  cost: string; status: MaintenanceStatus; performedBy: string; notes: string;
}

const emptyForm: MaintenanceFormData = {
  equipmentId: '', description: '', startDate: format(new Date(), 'yyyy-MM-dd'),
  endDate: '', cost: '', status: 'Scheduled', performedBy: '', notes: '',
};

interface MaintenanceWithName extends Maintenance {
  equipmentName: string;
}

export default function MaintenanceManagement() {
  const [records, setRecords] = useState<MaintenanceWithName[]>([]);
  const [allEquipment, setAllEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<MaintenanceFormData>(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState<Maintenance | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [maintenanceData, equipmentData] = await Promise.all([
        MaintenanceDAO.findAll(),
        EquipmentDAO.findAll(),
      ]);

      setAllEquipment(equipmentData);

      const withNames = await Promise.all(
        maintenanceData.map(async m => {
          const eq = await EquipmentDAO.findById(m.equipmentId);
          return { ...m, equipmentName: eq?.name || m.equipmentId };
        })
      );

      setRecords(withNames.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime()));
    } catch (error) {
      console.error('Error loading maintenance:', error);
      showToast('Failed to load maintenance records', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => { loadData(); }, [loadData]);

  const filtered = useMemo(() => {
    return records.filter(m => {
      const term = searchTerm.toLowerCase();
      const matchSearch = term === '' || m.id.toLowerCase().includes(term) || m.equipmentName.toLowerCase().includes(term) || m.performedBy.toLowerCase().includes(term);
      const matchStatus = filterStatus === 'All' || m.status === filterStatus;
      return matchSearch && matchStatus;
    });
  }, [records, searchTerm, filterStatus]);

  const openAdd = () => { setEditingId(null); setForm(emptyForm); setShowForm(true); };

  const openEdit = (m: Maintenance) => {
    setEditingId(m.id);
    setForm({
      equipmentId: m.equipmentId, description: m.description,
      startDate: format(new Date(m.startDate), 'yyyy-MM-dd'),
      endDate: m.endDate ? format(new Date(m.endDate), 'yyyy-MM-dd') : '',
      cost: String(m.cost), status: m.status, performedBy: m.performedBy, notes: m.notes,
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.equipmentId) { showToast('Please select equipment', 'error'); return; }
    if (!form.description.trim()) { showToast('Description is required', 'error'); return; }
    if (!form.startDate) { showToast('Start date is required', 'error'); return; }

    setSaving(true);
    try {
      const existing = editingId ? await MaintenanceDAO.findById(editingId) : null;
      const maintenance: Maintenance = {
        id: editingId || await MaintenanceDAO.generateId(),
        equipmentId: form.equipmentId,
        description: form.description.trim(),
        startDate: new Date(form.startDate),
        endDate: form.endDate ? new Date(form.endDate) : undefined,
        cost: Number(form.cost) || 0,
        status: form.status,
        performedBy: form.performedBy.trim(),
        notes: form.notes.trim(),
        createdAt: existing?.createdAt || new Date(),
      };

      await MaintenanceDAO.save(maintenance);

      // Update equipment status based on maintenance status
      if (form.status === 'In Progress' || form.status === 'Scheduled') {
        await EquipmentDAO.updateStatus(form.equipmentId, 'Maintenance');
      } else if (form.status === 'Completed') {
        const otherActive = (await MaintenanceDAO.findByEquipment(form.equipmentId))
          .filter(m => m.id !== maintenance.id && (m.status === 'In Progress' || m.status === 'Scheduled'));
        if (otherActive.length === 0) {
          await EquipmentDAO.updateStatus(form.equipmentId, 'Available');
        }
      }

      await loadData();
      setShowForm(false);
      showToast(editingId ? 'Maintenance record updated' : 'Maintenance record created', 'success');
    } catch (error) {
      console.error('Error saving maintenance:', error);
      showToast('Failed to save maintenance record', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (deleteTarget) {
      try {
        await MaintenanceDAO.delete(deleteTarget.id);
        await loadData();
        setDeleteTarget(null);
        showToast('Maintenance record deleted', 'success');
      } catch (error) {
        console.error('Error deleting maintenance:', error);
        showToast('Failed to delete maintenance record', 'error');
      }
    }
  };

  const updateField = (field: keyof MaintenanceFormData, value: string) => setForm(prev => ({ ...prev, [field]: value }));

  const statusBadge = (status: MaintenanceStatus) => {
    const cls = status === 'Scheduled' ? 'badge-scheduled' : status === 'In Progress' ? 'badge-inprogress' : 'badge-completed';
    return <span className={`badge ${cls}`}>{status}</span>;
  };

  const totalCost = useMemo(() => records.reduce((s, m) => s + m.cost, 0), [records]);

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading maintenance records...</span>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {toast.visible && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9' }}>Maintenance Management</h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>Track equipment maintenance and costs</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="glass-button" onClick={loadData}><RefreshCw size={16} /></button>
          <button className="glass-button glass-button-primary" onClick={openAdd}><Plus size={16} /> Add Record</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '16px' }}>
        <div className="glass-card stat-card-amber" style={{ padding: '16px 20px' }}>
          <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Total Records</p>
          <p style={{ fontSize: '24px', fontWeight: 800, color: '#fbbf24', marginTop: '4px' }}>{records.length}</p>
        </div>
        <div className="glass-card stat-card-red" style={{ padding: '16px 20px' }}>
          <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Total Cost</p>
          <p style={{ fontSize: '24px', fontWeight: 800, color: '#f87171', marginTop: '4px' }}>${totalCost.toLocaleString()}</p>
        </div>
        <div className="glass-card stat-card-blue" style={{ padding: '16px 20px' }}>
          <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Active</p>
          <p style={{ fontSize: '24px', fontWeight: 800, color: '#60a5fa', marginTop: '4px' }}>{records.filter(m => m.status !== 'Completed').length}</p>
        </div>
      </div>

      <div className="glass-card" style={{ padding: '16px 20px', marginBottom: '16px', display: 'flex', gap: '12px', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
          <input className="glass-input" style={{ paddingLeft: '36px' }} placeholder="Search maintenance records..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Filter size={14} color="rgba(255,255,255,0.5)" />
          <select className="glass-select" style={{ width: '160px' }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="All">All Status</option>
            <option value="Scheduled">Scheduled</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>

      <div className="glass-card" style={{ flex: 1, overflow: 'auto', padding: '2px' }}>
        <table className="glass-table">
          <thead><tr><th>ID</th><th>Equipment</th><th>Description</th><th>Start</th><th>End</th><th>Cost</th><th>Performed By</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={9} style={{ textAlign: 'center', padding: '40px', color: 'rgba(255,255,255,0.4)' }}>
                <Wrench size={40} style={{ marginBottom: '10px', opacity: 0.3 }} /><p>No maintenance records found</p>
              </td></tr>
            ) : (
              filtered.map(m => (
                <tr key={m.id}>
                  <td style={{ fontFamily: 'monospace' }}>{m.id}</td>
                  <td style={{ fontWeight: 600, color: '#e2e8f0' }}>{m.equipmentName}</td>
                  <td style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.description}</td>
                  <td>{format(new Date(m.startDate), 'MMM dd, yyyy')}</td>
                  <td>{m.endDate ? format(new Date(m.endDate), 'MMM dd, yyyy') : '—'}</td>
                  <td style={{ fontWeight: 600, color: '#fbbf24' }}>${m.cost.toLocaleString()}</td>
                  <td>{m.performedBy || '—'}</td>
                  <td>{statusBadge(m.status)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button className="glass-button" style={{ padding: '6px 10px' }} onClick={() => openEdit(m)}><Edit2 size={14} /></button>
                      <button className="glass-button glass-button-danger" style={{ padding: '6px 10px' }} onClick={() => setDeleteTarget(m)}><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title={editingId ? 'Edit Maintenance Record' : 'Add Maintenance Record'} onClose={() => setShowForm(false)} width="580px">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Equipment *</label>
              <select className="glass-select" value={form.equipmentId} onChange={e => updateField('equipmentId', e.target.value)}>
                <option value="">Select equipment...</option>
                {allEquipment.map(eq => <option key={eq.id} value={eq.id}>{eq.name} ({eq.id})</option>)}
              </select>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Description *</label>
              <input className="glass-input" value={form.description} onChange={e => updateField('description', e.target.value)} placeholder="What maintenance is being done?" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Start Date *</label>
              <input className="glass-input" type="date" value={form.startDate} onChange={e => updateField('startDate', e.target.value)} />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>End Date</label>
              <input className="glass-input" type="date" value={form.endDate} onChange={e => updateField('endDate', e.target.value)} min={form.startDate} />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Cost ($)</label>
              <input className="glass-input" type="number" value={form.cost} onChange={e => updateField('cost', e.target.value)} placeholder="0" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Status</label>
              <select className="glass-select" value={form.status} onChange={e => updateField('status', e.target.value)}>
                <option value="Scheduled">Scheduled</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Performed By</label>
              <input className="glass-input" value={form.performedBy} onChange={e => updateField('performedBy', e.target.value)} placeholder="Service provider" />
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Notes</label>
              <textarea className="glass-textarea" value={form.notes} onChange={e => updateField('notes', e.target.value)} placeholder="Additional notes..." />
            </div>
          </div>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '22px' }}>
            <button className="glass-button" onClick={() => setShowForm(false)}>Cancel</button>
            <button className="glass-button glass-button-primary" onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 size={16} className="animate-spin" /> : null}{editingId ? 'Update' : 'Add Record'}
            </button>
          </div>
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog title="Delete Maintenance Record" message={`Delete maintenance record "${deleteTarget.id}"?`} onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} confirmText="Delete" danger />
      )}
    </div>
  );
}
