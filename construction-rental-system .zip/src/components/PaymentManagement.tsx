import { useState, useMemo, useCallback, useEffect } from 'react';
import { PaymentDAO, RentalDAO, CustomerDAO } from '../store/unifiedStore';
import { Payment, PaymentMethod, Rental, Customer } from '../types';
import { Plus, Search, DollarSign, CreditCard, Filter, Loader2, RefreshCw } from 'lucide-react';
import Modal from './ui/Modal';
import Toast from './ui/Toast';
import { useToast } from '../hooks/useToast';
import { format } from 'date-fns';

interface PaymentWithCustomer extends Payment {
  customerName: string;
}

interface RentalWithBalance {
  rental: Rental;
  customer: Customer | null;
  totalPaid: number;
  finalAmount: number;
  balance: number;
}

export default function PaymentManagement() {
  const [payments, setPayments] = useState<PaymentWithCustomer[]>([]);
  const [rentalsWithBalance, setRentalsWithBalance] = useState<RentalWithBalance[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMethod, setFilterMethod] = useState('All');
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  const [selectedRentalId, setSelectedRentalId] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [reference, setReference] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [paymentsData, rentalsData] = await Promise.all([
        PaymentDAO.findAll(),
        RentalDAO.findAll(),
      ]);

      // Payments with customer names
      const paymentsWithDetails = await Promise.all(
        paymentsData.map(async p => {
          const rental = await RentalDAO.findById(p.rentalId);
          const customer = rental ? await CustomerDAO.findById(rental.customerId) : null;
          return {
            ...p,
            customerName: customer ? `${customer.firstName} ${customer.lastName}` : 'N/A',
          };
        })
      );
      setPayments(paymentsWithDetails.sort((a, b) => 
        new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime()
      ));

      // Rentals with balance
      const withBalance = await Promise.all(
        rentalsData
          .filter(r => r.status === 'Active' || r.status === 'Returned')
          .map(async r => {
            const customer = await CustomerDAO.findById(r.customerId);
            const totalPaid = await PaymentDAO.getTotalByRental(r.id);
            const finalAmount = r.totalAmount + r.lateFee + r.damageFee;
            return { rental: r, customer, totalPaid, finalAmount, balance: finalAmount - totalPaid };
          })
      );
      setRentalsWithBalance(withBalance.filter(r => r.balance > 0));
    } catch (error) {
      console.error('Error loading payments:', error);
      showToast('Failed to load payments', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => { loadData(); }, [loadData]);

  const filtered = useMemo(() => {
    return payments.filter(p => {
      const term = searchTerm.toLowerCase();
      const matchSearch = term === '' || p.id.toLowerCase().includes(term) || p.rentalId.toLowerCase().includes(term) || p.customerName.toLowerCase().includes(term) || p.reference.toLowerCase().includes(term);
      const matchMethod = filterMethod === 'All' || p.paymentMethod === filterMethod;
      return matchSearch && matchMethod;
    });
  }, [payments, searchTerm, filterMethod]);

  const selectedRentalInfo = useMemo(() => {
    if (!selectedRentalId) return null;
    return rentalsWithBalance.find(r => r.rental.id === selectedRentalId) || null;
  }, [selectedRentalId, rentalsWithBalance]);

  const handleAddPayment = async () => {
    if (!selectedRentalId) { showToast('Please select a rental', 'error'); return; }
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) { showToast('Please enter a valid amount', 'error'); return; }
    if (selectedRentalInfo && Number(amount) > selectedRentalInfo.balance) {
      showToast('Amount exceeds remaining balance', 'warning');
      return;
    }

    setSaving(true);
    try {
      const paymentId = await PaymentDAO.generateId();
      const payment: Payment = {
        id: paymentId,
        rentalId: selectedRentalId,
        amount: Number(amount),
        paymentDate: new Date(),
        paymentMethod,
        reference: reference.trim() || `TXN-${Date.now()}`,
        notes: paymentNotes.trim(),
        createdAt: new Date(),
      };

      await PaymentDAO.save(payment);
      await loadData();
      setShowForm(false);
      setSelectedRentalId('');
      setAmount('');
      setReference('');
      setPaymentNotes('');
      showToast('Payment recorded successfully', 'success');
    } catch (error) {
      console.error('Error recording payment:', error);
      showToast('Failed to record payment', 'error');
    } finally {
      setSaving(false);
    }
  };

  const totalReceived = useMemo(() => payments.reduce((s, p) => s + p.amount, 0), [payments]);

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading payments...</span>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {toast.visible && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9' }}>Payment Management</h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>Record and track rental payments</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="glass-button" onClick={loadData}><RefreshCw size={16} /></button>
          <button className="glass-button glass-button-primary" onClick={() => setShowForm(true)}><Plus size={16} /> Record Payment</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '16px' }}>
        <div className="glass-card stat-card-green" style={{ padding: '16px 20px' }}>
          <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Total Received</p>
          <p style={{ fontSize: '24px', fontWeight: 800, color: '#34d399', marginTop: '4px' }}>${totalReceived.toLocaleString()}</p>
        </div>
        <div className="glass-card stat-card-amber" style={{ padding: '16px 20px' }}>
          <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Pending Balances</p>
          <p style={{ fontSize: '24px', fontWeight: 800, color: '#fbbf24', marginTop: '4px' }}>{rentalsWithBalance.length} rentals</p>
        </div>
        <div className="glass-card stat-card-blue" style={{ padding: '16px 20px' }}>
          <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase' }}>Total Transactions</p>
          <p style={{ fontSize: '24px', fontWeight: 800, color: '#60a5fa', marginTop: '4px' }}>{payments.length}</p>
        </div>
      </div>

      <div className="glass-card" style={{ padding: '16px 20px', marginBottom: '16px', display: 'flex', gap: '12px', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
          <input className="glass-input" style={{ paddingLeft: '36px' }} placeholder="Search payments..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Filter size={14} color="rgba(255,255,255,0.5)" />
          <select className="glass-select" style={{ width: '160px' }} value={filterMethod} onChange={e => setFilterMethod(e.target.value)}>
            <option value="All">All Methods</option>
            <option value="Cash">Cash</option>
            <option value="Card">Card</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Check">Check</option>
          </select>
        </div>
      </div>

      <div className="glass-card" style={{ flex: 1, overflow: 'auto', padding: '2px' }}>
        <table className="glass-table">
          <thead><tr><th>Payment ID</th><th>Rental ID</th><th>Customer</th><th>Amount</th><th>Method</th><th>Date</th><th>Reference</th><th>Notes</th></tr></thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={8} style={{ textAlign: 'center', padding: '40px', color: 'rgba(255,255,255,0.4)' }}>
                <CreditCard size={40} style={{ marginBottom: '10px', opacity: 0.3 }} /><p>No payments found</p>
              </td></tr>
            ) : (
              filtered.map(p => (
                <tr key={p.id}>
                  <td style={{ fontFamily: 'monospace' }}>{p.id}</td>
                  <td style={{ fontFamily: 'monospace', color: '#60a5fa' }}>{p.rentalId}</td>
                  <td style={{ fontWeight: 600 }}>{p.customerName}</td>
                  <td style={{ fontWeight: 700, color: '#34d399', fontSize: '14px' }}>${p.amount.toLocaleString()}</td>
                  <td><span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}><CreditCard size={12} color="rgba(255,255,255,0.4)" />{p.paymentMethod}</span></td>
                  <td>{format(new Date(p.paymentDate), 'MMM dd, yyyy')}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: '11px', color: 'rgba(255,255,255,0.5)' }}>{p.reference}</td>
                  <td style={{ color: 'rgba(255,255,255,0.5)', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.notes || '—'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title="Record Payment" onClose={() => setShowForm(false)} width="550px">
          <div style={{ marginBottom: '14px' }}>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Select Rental (with pending balance) *</label>
            <select className="glass-select" value={selectedRentalId} onChange={e => setSelectedRentalId(e.target.value)}>
              <option value="">Select a rental...</option>
              {rentalsWithBalance.map(r => (
                <option key={r.rental.id} value={r.rental.id}>
                  {r.rental.id} — {r.customer ? `${r.customer.firstName} ${r.customer.lastName}` : 'N/A'} — Balance: ${r.balance.toLocaleString()}
                </option>
              ))}
            </select>
          </div>

          {selectedRentalInfo && (
            <div style={{ padding: '12px', borderRadius: '10px', background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.15)', marginBottom: '14px', fontSize: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: 'rgba(255,255,255,0.5)' }}>Total Amount:</span>
                <span style={{ color: '#e2e8f0' }}>${selectedRentalInfo.finalAmount.toLocaleString()}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: 'rgba(255,255,255,0.5)' }}>Paid:</span>
                <span style={{ color: '#34d399' }}>${selectedRentalInfo.totalPaid.toLocaleString()}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700 }}>
                <span style={{ color: 'rgba(255,255,255,0.7)' }}>Remaining:</span>
                <span style={{ color: '#f87171' }}>${selectedRentalInfo.balance.toLocaleString()}</span>
              </div>
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Amount ($) *</label>
              <input className="glass-input" type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Payment Method *</label>
              <select className="glass-select" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}>
                <option value="Cash">Cash</option>
                <option value="Card">Card</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Check">Check</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Reference</label>
              <input className="glass-input" value={reference} onChange={e => setReference(e.target.value)} placeholder="Transaction reference" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Notes</label>
              <input className="glass-input" value={paymentNotes} onChange={e => setPaymentNotes(e.target.value)} placeholder="Optional notes..." />
            </div>
          </div>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '22px' }}>
            <button className="glass-button" onClick={() => setShowForm(false)}>Cancel</button>
            <button className="glass-button glass-button-primary" onClick={handleAddPayment} disabled={saving}>
              {saving ? <Loader2 size={16} className="animate-spin" /> : <DollarSign size={16} />} Record Payment
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
