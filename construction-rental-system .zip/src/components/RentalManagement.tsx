import { useState, useMemo, useCallback, useEffect } from 'react';
import { RentalDAO, RentalDetailDAO, CustomerDAO, EquipmentDAO, PaymentDAO, RentalPricingService } from '../store/unifiedStore';
import { Rental, RentalDetail, Equipment, Customer, Payment } from '../types';
import { Plus, Search, FileText, Eye, Filter, Loader2, RefreshCw } from 'lucide-react';
import Modal from './ui/Modal';
import Toast from './ui/Toast';
import { useToast } from '../hooks/useToast';
import { format, differenceInDays } from 'date-fns';

interface RentalWithDetails extends Rental {
  customerName: string;
  totalPaid: number;
  finalAmount: number;
  balance: number;
}

interface ViewRentalData {
  rental: Rental;
  customer: Customer | null;
  details: (RentalDetail & { equipmentName: string })[];
  payments: Payment[];
  totalPaid: number;
  balance: number;
}

export default function RentalManagement() {
  const [rentals, setRentals] = useState<RentalWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [showForm, setShowForm] = useState(false);
  const [viewRental, setViewRental] = useState<ViewRentalData | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  // Form state
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [deposit, setDeposit] = useState('');
  const [notes, setNotes] = useState('');
  const [selectedEquipmentIds, setSelectedEquipmentIds] = useState<string[]>([]);
  
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [availableEquipment, setAvailableEquipment] = useState<Equipment[]>([]);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [rentalsData, customersData, equipmentData] = await Promise.all([
        RentalDAO.findAll(),
        CustomerDAO.findAll(),
        EquipmentDAO.findByStatus('Available'),
      ]);

      setCustomers(customersData);
      setAvailableEquipment(equipmentData);

      const rentalsWithDetails = await Promise.all(
        rentalsData.map(async r => {
          const customer = await CustomerDAO.findById(r.customerId);
          const totalPaid = await PaymentDAO.getTotalByRental(r.id);
          const finalAmount = r.totalAmount + r.lateFee + r.damageFee;
          return {
            ...r,
            customerName: customer ? `${customer.firstName} ${customer.lastName}` : 'N/A',
            totalPaid,
            finalAmount,
            balance: finalAmount - totalPaid,
          };
        })
      );

      setRentals(rentalsWithDetails.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
    } catch (error) {
      console.error('Error loading rentals:', error);
      showToast('Failed to load rentals', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => { loadData(); }, [loadData]);

  const filtered = useMemo(() => {
    return rentals.filter(r => {
      const term = searchTerm.toLowerCase();
      const matchSearch = term === '' || r.id.toLowerCase().includes(term) || r.customerName.toLowerCase().includes(term);
      const matchStatus = filterStatus === 'All' || r.status === filterStatus;
      return matchSearch && matchStatus;
    });
  }, [rentals, searchTerm, filterStatus]);

  // Calculate pricing preview
  const pricingPreview = useMemo(() => {
    if (!startDate || !endDate || selectedEquipmentIds.length === 0) return null;
    const days = differenceInDays(new Date(endDate), new Date(startDate));
    if (days <= 0) return null;

    const items = selectedEquipmentIds.map(eqId => {
      const eq = availableEquipment.find(e => e.id === eqId);
      if (!eq) return null;
      const pricing = RentalPricingService.calculateRate(days, eq.dailyRate, eq.weeklyRate, eq.monthlyRate);
      return { equipment: eq, ...pricing, days };
    }).filter(Boolean) as { equipment: Equipment; appliedRate: number; subtotal: number; rateType: string; days: number }[];

    const total = items.reduce((sum, item) => sum + item.subtotal, 0);
    return { items, total, days };
  }, [startDate, endDate, selectedEquipmentIds, availableEquipment]);

  const openAdd = () => {
    setSelectedCustomerId('');
    setStartDate(format(new Date(), 'yyyy-MM-dd'));
    setEndDate('');
    setDeposit('');
    setNotes('');
    setSelectedEquipmentIds([]);
    setShowForm(true);
  };

  const toggleEquipment = (id: string) => {
    setSelectedEquipmentIds(prev =>
      prev.includes(id) ? prev.filter(eid => eid !== id) : [...prev, id]
    );
  };

  const handleCreateRental = async () => {
    if (!selectedCustomerId) { showToast('Please select a customer', 'error'); return; }
    if (!startDate || !endDate) { showToast('Please select start and end dates', 'error'); return; }
    if (selectedEquipmentIds.length === 0) { showToast('Please select at least one equipment', 'error'); return; }
    if (!pricingPreview) { showToast('Invalid date range', 'error'); return; }

    setSaving(true);
    try {
      const depositAmount = Number(deposit) || 0;
      const rentalId = await RentalDAO.generateId();

      // Create rental details
      const details: RentalDetail[] = pricingPreview.items.map(item => ({
        id: RentalDetailDAO.generateId(),
        rentalId,
        equipmentId: item.equipment.id,
        dailyRate: item.equipment.dailyRate,
        weeklyRate: item.equipment.weeklyRate,
        monthlyRate: item.equipment.monthlyRate,
        appliedRate: item.appliedRate,
        days: item.days,
        subtotal: item.subtotal,
      }));

      // Create rental
      const rental: Rental = {
        id: rentalId,
        customerId: selectedCustomerId,
        rentalDate: new Date(startDate),
        expectedReturnDate: new Date(endDate),
        status: 'Active',
        totalAmount: pricingPreview.total,
        deposit: depositAmount,
        lateFee: 0,
        damageFee: 0,
        notes: notes.trim(),
        createdBy: 'USR001',
        createdAt: new Date(),
      };

      await RentalDAO.save(rental);
      await RentalDetailDAO.saveAll(details);

      // Update equipment status to Rented
      for (const eqId of selectedEquipmentIds) {
        await EquipmentDAO.updateStatus(eqId, 'Rented');
      }

      // Create deposit payment if deposit > 0
      if (depositAmount > 0) {
        const paymentId = await PaymentDAO.generateId();
        await PaymentDAO.save({
          id: paymentId,
          rentalId,
          amount: depositAmount,
          paymentDate: new Date(),
          paymentMethod: 'Cash',
          reference: `DEP-${rentalId}`,
          notes: 'Deposit payment',
          createdAt: new Date(),
        });
      }

      await loadData();
      setShowForm(false);
      showToast('Rental created successfully', 'success');
    } catch (error) {
      console.error('Error creating rental:', error);
      showToast('Failed to create rental', 'error');
    } finally {
      setSaving(false);
    }
  };

  const loadViewRental = async (rental: Rental) => {
    try {
      const customer = await CustomerDAO.findById(rental.customerId);
      const details = await RentalDetailDAO.findByRental(rental.id);
      const payments = await PaymentDAO.findByRental(rental.id);
      const totalPaid = payments.reduce((s, p) => s + p.amount, 0);
      
      const detailsWithNames = await Promise.all(details.map(async d => ({
        ...d,
        equipmentName: (await EquipmentDAO.findById(d.equipmentId))?.name || d.equipmentId,
      })));

      setViewRental({
        rental,
        customer,
        details: detailsWithNames,
        payments,
        totalPaid,
        balance: rental.totalAmount + rental.lateFee + rental.damageFee - totalPaid,
      });
    } catch (error) {
      console.error('Error loading rental details:', error);
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: '#60a5fa' }} />
        <span style={{ marginLeft: '12px', color: 'rgba(255,255,255,0.6)' }}>Loading rentals...</span>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {toast.visible && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9' }}>Rental Management</h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '4px' }}>Create and manage equipment rentals</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="glass-button" onClick={loadData}><RefreshCw size={16} /></button>
          <button className="glass-button glass-button-primary" onClick={openAdd}><Plus size={16} /> New Rental</button>
        </div>
      </div>

      <div className="glass-card" style={{ padding: '16px 20px', marginBottom: '16px', display: 'flex', gap: '12px', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
          <input className="glass-input" style={{ paddingLeft: '36px' }} placeholder="Search by rental ID or customer..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Filter size={14} color="rgba(255,255,255,0.5)" />
          <select className="glass-select" style={{ width: '140px' }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Returned">Returned</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>
      </div>

      <div className="glass-card" style={{ flex: 1, overflow: 'auto', padding: '2px' }}>
        <table className="glass-table">
          <thead>
            <tr>
              <th>Rental ID</th><th>Customer</th><th>Start Date</th><th>End Date</th><th>Total</th>
              <th>Deposit</th><th>Paid</th><th>Balance</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={10} style={{ textAlign: 'center', padding: '40px', color: 'rgba(255,255,255,0.4)' }}>
                <FileText size={40} style={{ marginBottom: '10px', opacity: 0.3 }} /><p>No rentals found</p>
              </td></tr>
            ) : (
              filtered.map(r => (
                <tr key={r.id}>
                  <td style={{ fontFamily: 'monospace', fontWeight: 600 }}>{r.id}</td>
                  <td style={{ fontWeight: 600, color: '#e2e8f0' }}>{r.customerName}</td>
                  <td>{format(new Date(r.rentalDate), 'MMM dd, yyyy')}</td>
                  <td>{format(new Date(r.expectedReturnDate), 'MMM dd, yyyy')}</td>
                  <td style={{ fontWeight: 600 }}>${r.finalAmount.toLocaleString()}</td>
                  <td style={{ color: '#fbbf24' }}>${r.deposit.toLocaleString()}</td>
                  <td style={{ color: '#34d399' }}>${r.totalPaid.toLocaleString()}</td>
                  <td style={{ color: r.balance > 0 ? '#f87171' : '#34d399', fontWeight: 600 }}>${r.balance.toLocaleString()}</td>
                  <td><span className={`badge badge-${r.status.toLowerCase()}`}>{r.status}</span></td>
                  <td>
                    <button className="glass-button" style={{ padding: '6px 10px' }} onClick={() => loadViewRental(r)}><Eye size={14} /></button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title="Create New Rental" onClose={() => setShowForm(false)} width="750px">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Customer *</label>
              <select className="glass-select" value={selectedCustomerId} onChange={e => setSelectedCustomerId(e.target.value)}>
                <option value="">Select a customer...</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.firstName} {c.lastName} — {c.company}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Start Date *</label>
              <input className="glass-input" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Expected Return Date *</label>
              <input className="glass-input" type="date" value={endDate} onChange={e => setEndDate(e.target.value)} min={startDate} />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Deposit ($)</label>
              <input className="glass-input" type="number" value={deposit} onChange={e => setDeposit(e.target.value)} placeholder="0" />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '4px', display: 'block' }}>Notes</label>
              <input className="glass-input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Optional notes..." />
            </div>
          </div>

          <div style={{ marginTop: '18px' }}>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '8px', display: 'block' }}>
              Select Equipment * ({selectedEquipmentIds.length} selected)
            </label>
            <div style={{ maxHeight: '200px', overflowY: 'auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              {availableEquipment.map(eq => {
                const selected = selectedEquipmentIds.includes(eq.id);
                return (
                  <div key={eq.id} onClick={() => toggleEquipment(eq.id)} style={{
                    padding: '12px', borderRadius: '10px', cursor: 'pointer',
                    background: selected ? 'rgba(59,130,246,0.15)' : 'rgba(255,255,255,0.03)',
                    border: selected ? '1px solid rgba(59,130,246,0.40)' : '1px solid rgba(255,255,255,0.06)',
                  }}>
                    <p style={{ fontSize: '13px', fontWeight: 600, color: selected ? '#60a5fa' : '#e2e8f0' }}>{eq.name}</p>
                    <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginTop: '2px' }}>
                      {eq.category} · ${eq.dailyRate}/day · ${eq.weeklyRate}/week · ${eq.monthlyRate}/month
                    </p>
                  </div>
                );
              })}
              {availableEquipment.length === 0 && (
                <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', gridColumn: '1/-1', padding: '20px', textAlign: 'center' }}>No available equipment</p>
              )}
            </div>
          </div>

          {pricingPreview && (
            <div style={{ marginTop: '18px', padding: '16px', borderRadius: '12px', background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.15)' }}>
              <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#60a5fa', marginBottom: '10px' }}>Pricing Preview — {pricingPreview.days} days</h4>
              {pricingPreview.items.map((item, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '6px' }}>
                  <span style={{ color: 'rgba(255,255,255,0.7)' }}>{item.equipment.name} ({item.rateType})</span>
                  <span style={{ fontWeight: 600, color: '#e2e8f0' }}>${item.subtotal.toLocaleString()}</span>
                </div>
              ))}
              <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', marginTop: '8px', paddingTop: '8px', display: 'flex', justifyContent: 'space-between', fontSize: '15px', fontWeight: 700 }}>
                <span style={{ color: '#e2e8f0' }}>Total</span>
                <span style={{ color: '#34d399' }}>${pricingPreview.total.toLocaleString()}</span>
              </div>
            </div>
          )}

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '22px' }}>
            <button className="glass-button" onClick={() => setShowForm(false)}>Cancel</button>
            <button className="glass-button glass-button-primary" onClick={handleCreateRental} disabled={saving}>
              {saving ? <Loader2 size={16} className="animate-spin" /> : null} Create Rental
            </button>
          </div>
        </Modal>
      )}

      {viewRental && (
        <Modal title={`Rental Details — ${viewRental.rental.id}`} onClose={() => setViewRental(null)} width="700px">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '18px' }}>
            <div style={{ padding: '12px', borderRadius: '10px', background: 'rgba(255,255,255,0.04)' }}>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginBottom: '2px' }}>Customer</p>
              <p style={{ fontSize: '14px', fontWeight: 600, color: '#e2e8f0' }}>
                {viewRental.customer ? `${viewRental.customer.firstName} ${viewRental.customer.lastName}` : 'N/A'}
              </p>
            </div>
            <div style={{ padding: '12px', borderRadius: '10px', background: 'rgba(255,255,255,0.04)' }}>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginBottom: '2px' }}>Status</p>
              <span className={`badge badge-${viewRental.rental.status.toLowerCase()}`}>{viewRental.rental.status}</span>
            </div>
            <div style={{ padding: '12px', borderRadius: '10px', background: 'rgba(255,255,255,0.04)' }}>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginBottom: '2px' }}>Rental Period</p>
              <p style={{ fontSize: '13px', color: '#e2e8f0' }}>
                {format(new Date(viewRental.rental.rentalDate), 'MMM dd, yyyy')} — {format(new Date(viewRental.rental.expectedReturnDate), 'MMM dd, yyyy')}
              </p>
            </div>
            <div style={{ padding: '12px', borderRadius: '10px', background: 'rgba(255,255,255,0.04)' }}>
              <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginBottom: '2px' }}>Balance</p>
              <p style={{ fontSize: '16px', fontWeight: 700, color: viewRental.balance > 0 ? '#f87171' : '#34d399' }}>
                ${viewRental.balance.toLocaleString()}
              </p>
            </div>
          </div>

          <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#f1f5f9', marginBottom: '8px' }}>Equipment</h4>
          <table className="glass-table" style={{ marginBottom: '18px' }}>
            <thead><tr><th>Equipment</th><th>Rate</th><th>Days</th><th>Subtotal</th></tr></thead>
            <tbody>
              {viewRental.details.map(d => (
                <tr key={d.id}>
                  <td style={{ fontWeight: 600 }}>{d.equipmentName}</td>
                  <td>${d.appliedRate.toLocaleString()}</td>
                  <td>{d.days}</td>
                  <td style={{ fontWeight: 600, color: '#34d399' }}>${d.subtotal.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {viewRental.payments.length > 0 && (
            <>
              <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#f1f5f9', marginBottom: '8px' }}>Payments</h4>
              <table className="glass-table">
                <thead><tr><th>Date</th><th>Method</th><th>Amount</th><th>Reference</th></tr></thead>
                <tbody>
                  {viewRental.payments.map(p => (
                    <tr key={p.id}>
                      <td>{format(new Date(p.paymentDate), 'MMM dd, yyyy')}</td>
                      <td>{p.paymentMethod}</td>
                      <td style={{ fontWeight: 600, color: '#34d399' }}>${p.amount.toLocaleString()}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: '11px' }}>{p.reference}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </Modal>
      )}
    </div>
  );
}
