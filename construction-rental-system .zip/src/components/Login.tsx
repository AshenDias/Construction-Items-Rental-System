import { useState } from 'react';
import { UserDAO } from '../store/unifiedStore';
import { User } from '../types';
import { Lock, User as UserIcon, LogIn, HardHat, Eye, EyeOff } from 'lucide-react';
import Toast from './ui/Toast';
import { useToast } from '../hooks/useToast';

interface LoginProps {
  onLogin: (user: User) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      showToast('Please enter both username and password', 'warning');
      return;
    }
    setLoading(true);
    // Async login
    const doLogin = async () => {
      try {
        const user = await UserDAO.findByCredentials(username.trim(), password);
        if (user) {
          showToast(`Welcome back, ${user.fullName}!`, 'success');
          setTimeout(() => onLogin(user), 800);
        } else {
          showToast('Invalid username or password', 'error');
          setLoading(false);
        }
      } catch (error) {
        console.error('Login error:', error);
        showToast('Login failed. Please try again.', 'error');
        setLoading(false);
      }
    };
    doLogin();
  };

  return (
    <div className="login-bg" style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
      {toast.visible && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}

      {/* Floating orbs */}
      <div style={{
        position: 'absolute', width: '300px', height: '300px', borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(59,130,246,0.08) 0%, transparent 70%)',
        top: '10%', left: '15%', animation: 'float 8s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute', width: '200px', height: '200px', borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(139,92,246,0.06) 0%, transparent 70%)',
        bottom: '20%', right: '10%', animation: 'float 10s ease-in-out infinite reverse',
      }} />

      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: '420px', padding: '0 20px' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '36px' }}>
          <div style={{
            width: '72px', height: '72px', borderRadius: '20px',
            background: 'linear-gradient(135deg, rgba(59,130,246,0.25), rgba(139,92,246,0.25))',
            border: '1px solid rgba(255,255,255,0.15)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 18px',
            boxShadow: '0 8px 32px rgba(59,130,246,0.2)',
          }}>
            <HardHat size={36} color="#60a5fa" />
          </div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#f1f5f9', letterSpacing: '-0.02em' }}>
            ConstructRent<span style={{ color: '#3b82f6' }}>Pro</span>
          </h1>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginTop: '6px' }}>
            Equipment Rental Management System
          </p>
        </div>

        {/* Login Form */}
        <div className="glass-card" style={{ padding: '32px' }}>
          <h2 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '6px', color: '#f1f5f9' }}>Welcome Back</h2>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.45)', marginBottom: '28px' }}>
            Sign in to your account
          </p>

          <form onSubmit={handleLogin}>
            <div style={{ marginBottom: '18px' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '6px', display: 'block', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Username
              </label>
              <div style={{ position: 'relative' }}>
                <UserIcon size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
                <input
                  className="glass-input"
                  style={{ paddingLeft: '40px' }}
                  type="text"
                  placeholder="Enter username"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  autoFocus
                />
              </div>
            </div>

            <div style={{ marginBottom: '28px' }}>
              <label style={{ fontSize: '12px', fontWeight: 600, color: 'rgba(255,255,255,0.6)', marginBottom: '6px', display: 'block', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <Lock size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.35)' }} />
                <input
                  className="glass-input"
                  style={{ paddingLeft: '40px', paddingRight: '42px' }}
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)',
                    background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.35)',
                    padding: '4px', display: 'flex',
                  }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="glass-button glass-button-primary"
              disabled={loading}
              style={{ width: '100%', justifyContent: 'center', padding: '13px 20px', fontSize: '15px', fontWeight: 600 }}
            >
              {loading ? (
                <div style={{
                  width: '18px', height: '18px', border: '2px solid rgba(255,255,255,0.3)',
                  borderTopColor: 'white', borderRadius: '50%', animation: 'spin 0.6s linear infinite',
                }} />
              ) : (
                <>
                  <LogIn size={18} />
                  Sign In
                </>
              )}
            </button>
          </form>

          <div style={{
            marginTop: '24px', padding: '14px', borderRadius: '10px',
            background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.15)',
          }}>
            <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.45)', marginBottom: '6px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Demo Credentials
            </p>
            <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.65)' }}>
              Admin: <code style={{ color: '#60a5fa' }}>admin</code> / <code style={{ color: '#60a5fa' }}>admin123</code>
            </p>
            <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.65)', marginTop: '2px' }}>
              Staff: <code style={{ color: '#60a5fa' }}>staff</code> / <code style={{ color: '#60a5fa' }}>staff123</code>
            </p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-20px); }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
