// ============================================
// FIREBASE CONFIGURATION
// ============================================
// 
// 🔥 SETUP INSTRUCTIONS:
// 
// 1. Go to https://console.firebase.google.com/
// 2. Click "Create a project" (or use existing)
// 3. Name it: "constructrent-pro" (or any name)
// 4. Disable Google Analytics (optional, not needed)
// 5. Click "Create project"
// 
// 6. In your project, click the web icon </> to add a web app
// 7. Name it: "ConstructRentPro"
// 8. DON'T check "Firebase Hosting" for now
// 9. Click "Register app"
// 10. Copy the firebaseConfig object and replace below
//
// 11. Go to "Build" → "Firestore Database" in sidebar
// 12. Click "Create database"
// 13. Choose "Start in test mode" (for development)
// 14. Select nearest location, click "Enable"
//
// 15. Go to "Build" → "Authentication" in sidebar
// 16. Click "Get started"
// 17. Enable "Email/Password" provider
//
// ============================================

import { initializeApp } from 'firebase/app';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

// ⚠️ REPLACE THIS WITH YOUR FIREBASE CONFIG
// Get this from: Firebase Console → Project Settings → Your apps → Config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Check if Firebase is configured
export const isFirebaseConfigured = () => {
  return firebaseConfig.apiKey !== "YOUR_API_KEY_HERE" && 
         firebaseConfig.projectId !== "YOUR_PROJECT_ID";
};

// Initialize Firebase
let app: ReturnType<typeof initializeApp> | null = null;
let db: ReturnType<typeof getFirestore> | null = null;
let auth: ReturnType<typeof getAuth> | null = null;

if (isFirebaseConfigured()) {
  try {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    auth = getAuth(app);
    
    // Enable offline persistence for mobile/PWA
    enableIndexedDbPersistence(db).catch((err) => {
      if (err.code === 'failed-precondition') {
        console.warn('Persistence failed: Multiple tabs open');
      } else if (err.code === 'unimplemented') {
        console.warn('Persistence not supported by browser');
      }
    });
    
    console.log('✅ Firebase initialized successfully');
  } catch (error) {
    console.error('❌ Firebase initialization error:', error);
  }
} else {
  console.warn('⚠️ Firebase not configured - using local storage mode');
}

export { app, db, auth };
export default firebaseConfig;
