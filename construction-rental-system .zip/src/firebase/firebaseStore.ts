// ============================================
// FIREBASE FIRESTORE DATA OPERATIONS
// Real-time sync across all devices
// ============================================

import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  writeBatch,
  Timestamp,
} from 'firebase/firestore';
import { db } from './config';
import {
  User, Equipment, Customer, Rental, RentalDetail,
  Payment, Maintenance, EquipmentStatus,
} from '../types';

// Collection names
const COLLECTIONS = {
  users: 'users',
  equipment: 'equipment',
  customers: 'customers',
  rentals: 'rentals',
  rentalDetails: 'rental_details',
  payments: 'payments',
  maintenance: 'maintenance',
};

// Convert Firestore Timestamp to Date
const convertTimestamps = <T>(data: T): T => {
  if (!data || typeof data !== 'object') return data;
  
  const converted: Record<string, unknown> = { ...data as Record<string, unknown> };
  for (const key in converted) {
    const value = converted[key];
    if (value instanceof Timestamp) {
      converted[key] = value.toDate();
    } else if (value && typeof value === 'object' && 'seconds' in (value as object)) {
      converted[key] = new Date((value as { seconds: number }).seconds * 1000);
    }
  }
  return converted as T;
};

// ============================================
// USER OPERATIONS
// ============================================
export const FirebaseUserDAO = {
  findAll: async (): Promise<User[]> => {
    if (!db) return [];
    const snapshot = await getDocs(collection(db, COLLECTIONS.users));
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as User));
  },

  findById: async (id: string): Promise<User | null> => {
    if (!db) return null;
    const docRef = doc(db, COLLECTIONS.users, id);
    const docSnap = await getDoc(docRef);
    return docSnap.exists() ? convertTimestamps({ id: docSnap.id, ...docSnap.data() } as User) : null;
  },

  findByCredentials: async (username: string, password: string): Promise<User | null> => {
    if (!db) return null;
    const q = query(
      collection(db, COLLECTIONS.users),
      where('username', '==', username),
      where('password', '==', password),
      where('active', '==', true)
    );
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    const d = snapshot.docs[0];
    return convertTimestamps({ id: d.id, ...d.data() } as User);
  },

  save: async (user: User): Promise<void> => {
    if (!db) return;
    await setDoc(doc(db, COLLECTIONS.users, user.id), {
      ...user,
      createdAt: user.createdAt instanceof Date ? Timestamp.fromDate(user.createdAt) : user.createdAt,
    });
  },
};

// ============================================
// EQUIPMENT OPERATIONS
// ============================================
export const FirebaseEquipmentDAO = {
  findAll: async (): Promise<Equipment[]> => {
    if (!db) return [];
    const snapshot = await getDocs(collection(db, COLLECTIONS.equipment));
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Equipment));
  },

  findById: async (id: string): Promise<Equipment | null> => {
    if (!db) return null;
    const docRef = doc(db, COLLECTIONS.equipment, id);
    const docSnap = await getDoc(docRef);
    return docSnap.exists() ? convertTimestamps({ id: docSnap.id, ...docSnap.data() } as Equipment) : null;
  },

  findByStatus: async (status: EquipmentStatus): Promise<Equipment[]> => {
    if (!db) return [];
    const q = query(collection(db, COLLECTIONS.equipment), where('status', '==', status));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Equipment));
  },

  save: async (equipment: Equipment): Promise<void> => {
    if (!db) return;
    await setDoc(doc(db, COLLECTIONS.equipment, equipment.id), {
      ...equipment,
      purchaseDate: equipment.purchaseDate instanceof Date ? Timestamp.fromDate(equipment.purchaseDate) : equipment.purchaseDate,
      createdAt: equipment.createdAt instanceof Date ? Timestamp.fromDate(equipment.createdAt) : equipment.createdAt,
    });
  },

  delete: async (id: string): Promise<boolean> => {
    if (!db) return false;
    await deleteDoc(doc(db, COLLECTIONS.equipment, id));
    return true;
  },

  updateStatus: async (id: string, status: EquipmentStatus): Promise<void> => {
    const equipment = await FirebaseEquipmentDAO.findById(id);
    if (equipment) {
      equipment.status = status;
      await FirebaseEquipmentDAO.save(equipment);
    }
  },

  onSnapshot: (callback: (equipment: Equipment[]) => void): (() => void) => {
    if (!db) return () => {};
    return onSnapshot(collection(db, COLLECTIONS.equipment), (snapshot) => {
      const data = snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Equipment));
      callback(data);
    });
  },

  generateId: async (): Promise<string> => {
    const all = await FirebaseEquipmentDAO.findAll();
    const maxNum = all.reduce((max, e) => {
      const num = parseInt(e.id.replace('EQP', ''));
      return num > max ? num : max;
    }, 0);
    return `EQP${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ============================================
// CUSTOMER OPERATIONS
// ============================================
export const FirebaseCustomerDAO = {
  findAll: async (): Promise<Customer[]> => {
    if (!db) return [];
    const snapshot = await getDocs(collection(db, COLLECTIONS.customers));
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Customer));
  },

  findById: async (id: string): Promise<Customer | null> => {
    if (!db) return null;
    const docRef = doc(db, COLLECTIONS.customers, id);
    const docSnap = await getDoc(docRef);
    return docSnap.exists() ? convertTimestamps({ id: docSnap.id, ...docSnap.data() } as Customer) : null;
  },

  findByEmail: async (email: string): Promise<Customer | null> => {
    if (!db) return null;
    const q = query(collection(db, COLLECTIONS.customers), where('email', '==', email));
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    return convertTimestamps({ id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Customer);
  },

  save: async (customer: Customer): Promise<void> => {
    if (!db) return;
    await setDoc(doc(db, COLLECTIONS.customers, customer.id), {
      ...customer,
      createdAt: customer.createdAt instanceof Date ? Timestamp.fromDate(customer.createdAt) : customer.createdAt,
    });
  },

  delete: async (id: string): Promise<boolean> => {
    if (!db) return false;
    await deleteDoc(doc(db, COLLECTIONS.customers, id));
    return true;
  },

  onSnapshot: (callback: (customers: Customer[]) => void): (() => void) => {
    if (!db) return () => {};
    return onSnapshot(collection(db, COLLECTIONS.customers), (snapshot) => {
      const data = snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Customer));
      callback(data);
    });
  },

  generateId: async (): Promise<string> => {
    const all = await FirebaseCustomerDAO.findAll();
    const maxNum = all.reduce((max, c) => {
      const num = parseInt(c.id.replace('CUS', ''));
      return num > max ? num : max;
    }, 0);
    return `CUS${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ============================================
// RENTAL OPERATIONS
// ============================================
export const FirebaseRentalDAO = {
  findAll: async (): Promise<Rental[]> => {
    if (!db) return [];
    const snapshot = await getDocs(collection(db, COLLECTIONS.rentals));
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Rental));
  },

  findById: async (id: string): Promise<Rental | null> => {
    if (!db) return null;
    const docRef = doc(db, COLLECTIONS.rentals, id);
    const docSnap = await getDoc(docRef);
    return docSnap.exists() ? convertTimestamps({ id: docSnap.id, ...docSnap.data() } as Rental) : null;
  },

  findByCustomer: async (customerId: string): Promise<Rental[]> => {
    if (!db) return [];
    const q = query(collection(db, COLLECTIONS.rentals), where('customerId', '==', customerId));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Rental));
  },

  save: async (rental: Rental): Promise<void> => {
    if (!db) return;
    await setDoc(doc(db, COLLECTIONS.rentals, rental.id), {
      ...rental,
      rentalDate: rental.rentalDate instanceof Date ? Timestamp.fromDate(rental.rentalDate) : rental.rentalDate,
      expectedReturnDate: rental.expectedReturnDate instanceof Date ? Timestamp.fromDate(rental.expectedReturnDate) : rental.expectedReturnDate,
      actualReturnDate: rental.actualReturnDate instanceof Date ? Timestamp.fromDate(rental.actualReturnDate) : rental.actualReturnDate,
      createdAt: rental.createdAt instanceof Date ? Timestamp.fromDate(rental.createdAt) : rental.createdAt,
    });
  },

  onSnapshot: (callback: (rentals: Rental[]) => void): (() => void) => {
    if (!db) return () => {};
    return onSnapshot(collection(db, COLLECTIONS.rentals), (snapshot) => {
      const data = snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Rental));
      callback(data);
    });
  },

  generateId: async (): Promise<string> => {
    const all = await FirebaseRentalDAO.findAll();
    const maxNum = all.reduce((max, r) => {
      const num = parseInt(r.id.replace('RNT', ''));
      return num > max ? num : max;
    }, 0);
    return `RNT${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ============================================
// RENTAL DETAIL OPERATIONS
// ============================================
export const FirebaseRentalDetailDAO = {
  findAll: async (): Promise<RentalDetail[]> => {
    if (!db) return [];
    const snapshot = await getDocs(collection(db, COLLECTIONS.rentalDetails));
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as RentalDetail));
  },

  findByRental: async (rentalId: string): Promise<RentalDetail[]> => {
    if (!db) return [];
    const q = query(collection(db, COLLECTIONS.rentalDetails), where('rentalId', '==', rentalId));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as RentalDetail));
  },

  save: async (detail: RentalDetail): Promise<void> => {
    if (!db) return;
    await setDoc(doc(db, COLLECTIONS.rentalDetails, detail.id), detail);
  },

  saveAll: async (details: RentalDetail[]): Promise<void> => {
    if (!db) return;
    const batch = writeBatch(db);
    details.forEach(detail => {
      batch.set(doc(db!, COLLECTIONS.rentalDetails, detail.id), detail);
    });
    await batch.commit();
  },

  generateId: (): string => {
    return `RD${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
  },
};

// ============================================
// PAYMENT OPERATIONS
// ============================================
export const FirebasePaymentDAO = {
  findAll: async (): Promise<Payment[]> => {
    if (!db) return [];
    const snapshot = await getDocs(collection(db, COLLECTIONS.payments));
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Payment));
  },

  findByRental: async (rentalId: string): Promise<Payment[]> => {
    if (!db) return [];
    const q = query(collection(db, COLLECTIONS.payments), where('rentalId', '==', rentalId));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Payment));
  },

  save: async (payment: Payment): Promise<void> => {
    if (!db) return;
    await setDoc(doc(db, COLLECTIONS.payments, payment.id), {
      ...payment,
      paymentDate: payment.paymentDate instanceof Date ? Timestamp.fromDate(payment.paymentDate) : payment.paymentDate,
      createdAt: payment.createdAt instanceof Date ? Timestamp.fromDate(payment.createdAt) : payment.createdAt,
    });
  },

  getTotalByRental: async (rentalId: string): Promise<number> => {
    const payments = await FirebasePaymentDAO.findByRental(rentalId);
    return payments.reduce((sum, p) => sum + p.amount, 0);
  },

  onSnapshot: (callback: (payments: Payment[]) => void): (() => void) => {
    if (!db) return () => {};
    return onSnapshot(collection(db, COLLECTIONS.payments), (snapshot) => {
      const data = snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Payment));
      callback(data);
    });
  },

  generateId: async (): Promise<string> => {
    const all = await FirebasePaymentDAO.findAll();
    const maxNum = all.reduce((max, p) => {
      const num = parseInt(p.id.replace('PAY', ''));
      return num > max ? num : max;
    }, 0);
    return `PAY${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ============================================
// MAINTENANCE OPERATIONS
// ============================================
export const FirebaseMaintenanceDAO = {
  findAll: async (): Promise<Maintenance[]> => {
    if (!db) return [];
    const snapshot = await getDocs(collection(db, COLLECTIONS.maintenance));
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Maintenance));
  },

  findById: async (id: string): Promise<Maintenance | null> => {
    if (!db) return null;
    const docRef = doc(db, COLLECTIONS.maintenance, id);
    const docSnap = await getDoc(docRef);
    return docSnap.exists() ? convertTimestamps({ id: docSnap.id, ...docSnap.data() } as Maintenance) : null;
  },

  findByEquipment: async (equipmentId: string): Promise<Maintenance[]> => {
    if (!db) return [];
    const q = query(collection(db, COLLECTIONS.maintenance), where('equipmentId', '==', equipmentId));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Maintenance));
  },

  save: async (maintenance: Maintenance): Promise<void> => {
    if (!db) return;
    await setDoc(doc(db, COLLECTIONS.maintenance, maintenance.id), {
      ...maintenance,
      startDate: maintenance.startDate instanceof Date ? Timestamp.fromDate(maintenance.startDate) : maintenance.startDate,
      endDate: maintenance.endDate instanceof Date ? Timestamp.fromDate(maintenance.endDate) : maintenance.endDate,
      createdAt: maintenance.createdAt instanceof Date ? Timestamp.fromDate(maintenance.createdAt) : maintenance.createdAt,
    });
  },

  delete: async (id: string): Promise<boolean> => {
    if (!db) return false;
    await deleteDoc(doc(db, COLLECTIONS.maintenance, id));
    return true;
  },

  onSnapshot: (callback: (maintenance: Maintenance[]) => void): (() => void) => {
    if (!db) return () => {};
    return onSnapshot(collection(db, COLLECTIONS.maintenance), (snapshot) => {
      const data = snapshot.docs.map(d => convertTimestamps({ id: d.id, ...d.data() } as Maintenance));
      callback(data);
    });
  },

  generateId: async (): Promise<string> => {
    const all = await FirebaseMaintenanceDAO.findAll();
    const maxNum = all.reduce((max, m) => {
      const num = parseInt(m.id.replace('MNT', ''));
      return num > max ? num : max;
    }, 0);
    return `MNT${String(maxNum + 1).padStart(3, '0')}`;
  },
};

// ============================================
// SEED INITIAL DATA
// ============================================
export const seedInitialData = async (): Promise<void> => {
  if (!db) return;
  
  // Check if data already exists
  const equipmentSnapshot = await getDocs(collection(db, COLLECTIONS.equipment));
  if (!equipmentSnapshot.empty) {
    console.log('Data already exists, skipping seed');
    return;
  }

  console.log('Seeding initial data...');
  
  // Import sample data
  const { sampleUsers, sampleEquipment, sampleCustomers, sampleRentals, sampleRentalDetails, samplePayments, sampleMaintenance } = await import('../data/sampleData');

  const batch = writeBatch(db);

  // Seed users
  sampleUsers.forEach(user => {
    const docRef = doc(db!, COLLECTIONS.users, user.id);
    batch.set(docRef, {
      ...user,
      createdAt: Timestamp.fromDate(user.createdAt),
    });
  });

  // Seed equipment
  sampleEquipment.forEach(eq => {
    const docRef = doc(db!, COLLECTIONS.equipment, eq.id);
    batch.set(docRef, {
      ...eq,
      purchaseDate: Timestamp.fromDate(eq.purchaseDate),
      createdAt: Timestamp.fromDate(eq.createdAt),
    });
  });

  // Seed customers
  sampleCustomers.forEach(cust => {
    const docRef = doc(db!, COLLECTIONS.customers, cust.id);
    batch.set(docRef, {
      ...cust,
      createdAt: Timestamp.fromDate(cust.createdAt),
    });
  });

  // Seed rentals
  sampleRentals.forEach(rental => {
    const docRef = doc(db!, COLLECTIONS.rentals, rental.id);
    batch.set(docRef, {
      ...rental,
      rentalDate: Timestamp.fromDate(rental.rentalDate),
      expectedReturnDate: Timestamp.fromDate(rental.expectedReturnDate),
      actualReturnDate: rental.actualReturnDate ? Timestamp.fromDate(rental.actualReturnDate) : null,
      createdAt: Timestamp.fromDate(rental.createdAt),
    });
  });

  // Seed rental details
  sampleRentalDetails.forEach(detail => {
    const docRef = doc(db!, COLLECTIONS.rentalDetails, detail.id);
    batch.set(docRef, detail);
  });

  // Seed payments
  samplePayments.forEach(payment => {
    const docRef = doc(db!, COLLECTIONS.payments, payment.id);
    batch.set(docRef, {
      ...payment,
      paymentDate: Timestamp.fromDate(payment.paymentDate),
      createdAt: Timestamp.fromDate(payment.createdAt),
    });
  });

  // Seed maintenance
  sampleMaintenance.forEach(maint => {
    const docRef = doc(db!, COLLECTIONS.maintenance, maint.id);
    batch.set(docRef, {
      ...maint,
      startDate: Timestamp.fromDate(maint.startDate),
      endDate: maint.endDate ? Timestamp.fromDate(maint.endDate) : null,
      createdAt: Timestamp.fromDate(maint.createdAt),
    });
  });

  await batch.commit();
  console.log('✅ Initial data seeded successfully');
};
